<div class="header bg-gradient-white py-7 py-lg-8">
    <div class="container">
        <div class="header-body text-center mb-7">
            <div class="row justify-content-center">
                <div class="col-lg-9 col-md-9">
                    <h1 class="text-dark">{{ __('Bienvenido al Sistema de Gestión de la Coordinación de Lenguas Extranjeras.') }}</h1>
                </div>
            </div>
        </div>
    </div>
</div>