<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid m--t">
    <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center">
        <div class="col-lg col-md">
            <h4 class="text-dark">Evaluaci&oacute;n Docente</h4>
        </div>
    </div>
    <div class="card-body">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>

    <div class="text-right">
        <a href="<?php echo e(route('inicio')); ?>" class="btn btn-outline-primary btn-sm mt--3">
            <span>
                <i class="fas fa-reply"></i> &nbsp; Regresar
            </span>
        </a>
    </div>
    <form role="form" method="post" action="<?php echo e(route('guardarCambiosEvaluacion')); ?>" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="pl-lg-4" id="preguntas">
                     
                
            <hr class="my-4" />
            <h6 class="heading-small text-muted mb-4">Enfoque de Enseñanza</h6>
            <?php $i=0 ?>
            <?php $__currentLoopData = $enfoque; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pEnfoque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i++ ?>
            <div class="row" id="<?php echo e($pEnfoque->id_pregunta); ?>">
                
                    <a href="" data-idpreg="<?php echo e($pEnfoque->id_pregunta); ?>" data-preg="<?php echo e($pEnfoque->pregunta); ?>" data-toggle="modal" data-target="#modal-edit"><i class="fas fa-edit"></i></a>
                    <a href="" id="" data-preguntaid="<?php echo e($pEnfoque->id_pregunta); ?>" data-toggle="modal" data-target="#modal-delete"><i class="fas fa-eraser"></i></a>
                
                <input type="hidden" name="preg-res<?php echo e($i); ?>[]" value="<?php echo e($pEnfoque->id_pregunta); ?>">
                <div class="form-group col-md">
                        <div class="form-group col-md">
                                
                                <input type="text" class="form-control" id="input-estudios" name="estudios" value="<?php echo e($i.'.'); ?><?php echo e($pEnfoque->pregunta); ?>">
                                
                            </div>
                    <select id="input-pregunta" class="form-control col-md-4" name="preg-res<?php echo e($pEnfoque->id_pregunta); ?>[]">
                        <option selected value="">Elija una opci&oacute;n</option>
                        <?php echo e($respuestas = App\Respuesta::where('grupo_respuesta', $pEnfoque->id_respuesta)->get()); ?>

                        <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($respuesta->id_respuesta); ?>"><?php echo e($respuesta->respuesta); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <hr class="my-4" />
            <h6 class="heading-small text-muted mb-4">Clima Afectivo</h6>
            
            <?php $__currentLoopData = $clima; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $climaA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i++ ?>
            <div class="row" id="<?php echo e($climaA->id_pregunta); ?>">
                
                    <a href="" data-idpreg="<?php echo e($climaA->id_pregunta); ?>" data-preg="<?php echo e($climaA->pregunta); ?>" data-toggle="modal" data-target="#modal-edit"><i class="fas fa-edit"></i></a>
                    <a href="" id="" data-preguntaid="<?php echo e($climaA->id_pregunta); ?>" data-toggle="modal" data-target="#modal-delete"><i class="fas fa-eraser"></i></a>
                
                <input type="hidden" name="preg-res<?php echo e($i); ?>[]" value="<?php echo e($climaA->id_pregunta); ?>">
                <div class="form-group col-md">
                    <label class="form-control-label" for="input-pregunta"><?php echo e($i.'.'); ?><?php echo e($climaA->pregunta); ?></label>
                    <select id="input-pregunta" class="form-control col-md-4" name="preg-res<?php echo e($climaA->id_pregunta); ?>[]">
                        <option selected value="">Elija una opci&oacute;n</option>
                        <?php echo e($respuestas = App\Respuesta::where('grupo_respuesta', $climaA->id_respuesta)->get()); ?>

                        <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($respuesta->id_respuesta); ?>"><?php echo e($respuesta->respuesta); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <hr class="my-4" />
            <h6 class="heading-small text-muted mb-4">Proceso de Enseñanza</h6>
            
            <?php $__currentLoopData = $enseñanzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pEnseñanza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i++ ?>
            <div class="row" id="<?php echo e($pEnseñanza->id_pregunta); ?>">
                
                    <a href="" data-idpreg="<?php echo e($pEnseñanza->id_pregunta); ?>" data-preg="<?php echo e($pEnseñanza->pregunta); ?>" data-toggle="modal" data-target="#modal-edit"><i class="fas fa-edit"></i></a>
                    <a href="" id="" data-preguntaid="<?php echo e($pEnseñanza->id_pregunta); ?>" data-toggle="modal" data-target="#modal-delete"><i class="fas fa-eraser"></i></a>
                <input type="hidden" name="preg-res<?php echo e($i); ?>[]" value="<?php echo e($pEnseñanza->id_pregunta); ?>">
                <div class="form-group col-md">
                    <label class="form-control-label" for="input-pregunta"><?php echo e($i.'.'); ?><?php echo e($pEnseñanza->pregunta); ?></label>
                    <select id="input-pregunta" class="form-control col-md-4" name="preg-res<?php echo e($pEnseñanza->id_pregunta); ?>[]">
                        <option selected value="">Elija una opci&oacute;n</option>
                        <?php echo e($respuestas = App\Respuesta::where('grupo_respuesta', $pEnseñanza->id_respuesta)->get()); ?>

                        <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($respuesta->id_respuesta); ?>"><?php echo e($respuesta->respuesta); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <hr class="my-4" />
            <h6 class="heading-small text-muted mb-4">Estrategias de Retroalimentaci&oacute;n </h6>
           
            <?php $__currentLoopData = $retroalimentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retroa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i++ ?>
            <div class="row" id="<?php echo e($retroa->id_pregunta); ?>">
                
                <a href="" data-idpreg="<?php echo e($retroa->id_pregunta); ?>" data-preg="<?php echo e($retroa->pregunta); ?>" data-toggle="modal" data-target="#modal-edit"><i class="fas fa-edit"></i></a>
                <a href="" id="" data-preguntaid="<?php echo e($retroa->id_pregunta); ?>" data-toggle="modal" data-target="#modal-delete"><i class="fas fa-eraser"></i></a>
                
                <input type="hidden" name="preg-res<?php echo e($i); ?>[]" value="<?php echo e($retroa->id_pregunta); ?>">
                <div class="form-group col-md">
                    <label class="form-control-label" for="input-pregunta"><?php echo e($i.'.'); ?><?php echo e($retroa->pregunta); ?></label>
                    <select id="input-pregunta" class="form-control col-md-4" name="preg-res<?php echo e($retroa->id_pregunta); ?>[]">
                        <option selected value="">Elija una opci&oacute;n</option>
                        <?php echo e($respuestas = App\Respuesta::where('grupo_respuesta', $retroa->id_respuesta)->get()); ?>

                        <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($respuesta->id_respuesta); ?>"><?php echo e($respuesta->respuesta); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </select>
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($usuarioactual->tipo != 'coordinador'): ?>
                <div class="text-center">
                    <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Guardar')); ?></button>
                </div>
            <?php endif; ?>
            
    </form>
<br><br>
<?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="col-md-4">

    <div class="modal fade" id="modal-form2" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="card bg-lighter shadow border-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <div class="text-center text-muted mb-4">
                                <strong><?php echo e(__('Nueva Pregunta')); ?></strong>
                            </div>

                            <form role="form" method="post" action="<?php echo e(route('agregarPregunta')); ?>" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <input class="form-control" name="pregunta" placeholder="Pregunta" type="text" value="<?php echo e(old('pregunta')); ?>">
                                    </div>
                                </div>
                                <label class="form-control-label" for="input-tipo"><?php echo e(__('Clasificación de la Pregunta')); ?></label>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <select id="input-tipo" class="form-control" name="tipo">
                                            <option selected value="">Clasificaci&oacute;n</option>
                                            <?php $__currentLoopData = $tipoPregunta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tipo->tipo); ?>"><?php echo e($tipo->tipo); ?></option>    
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select>
                                    </div>
                                </div>
                                <label class="form-control-label" for="input-respuestas"><?php echo e(__('Grupos de Respuestas')); ?></label>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <select id="input-respuestas" class="form-control" name="respuestas">
                                            <option selected value="">Tipo de Respuestas</option>
                                            <?php $__currentLoopData = $grupoRs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r->id_grupoRespuestas); ?>"><?php echo e($r->grupoRespuesta); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <label class="form-control-label" for="input-vigencia"><?php echo e(__('Año de Vigencia')); ?></label>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <select id="input-vigencia" class="form-control" name="vigencia">
                                            <?php $anio = date('Y') ?>
                                            <option selected value="">Vigencia</option> 
                                            
                                            <?php for($i = 0; $i < 6; $i++): ?>
                                                <option value="<?php echo e($anio+$i); ?>"><?php echo e($anio+$i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Guardar')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>




<div class="col-md-4">
    <div class="modal fade" id="modal-delete" tabindex="-1" role="dialog" aria-labelledby="modal-notification" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-" role="document">
            <div class="modal-content bg-gradient-white">
                
                <div class="modal-header">
                    <h6 class="modal-title" id="modal-title-notification">¡Espera!</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    
                </div>
                <form action="<?php echo e(route('eliminarPregunta','test')); ?>" method="POST" class="delete" id="deleteForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <div class="modal-body">
                    
                    <div class="py-3 text-center">
                            <i class="fas fa-times fa-3x" style="color:#CD5C5C;"></i>
                        <h4 class="heading mt-4">¡Da tu confirmaci&oacute;n para Eliminar!</h4>
                        <p>¿Realmente deseas eliminar la pregunta?</p>
                        <input type="hidden" name="idpregunta" id="idpregunta" value="">
                    </div>
                    
                </div>
                
                <div class="modal-footer">
                    <button type="submit" class="btn btn-white">S&iacute;, Eliminar</button>
                    <button type="button" class="btn btn-link text-gray ml-auto" data-dismiss="modal">No, Cambi&eacute; de opinion</button> 
                </div>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="col-md-4">

        <div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
            <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body p-0">
                        <div class="card bg-lighter shadow border-0">
                            <div class="card-body px-lg-5 py-lg-5">
                                <div class="text-center text-muted mb-4">
                                    <strong><?php echo e(__('Editar Pregunta')); ?></strong>
                                </div>
    
                                <form role="form" method="post" action="<?php echo e(route('guardarPregunta','test')); ?>" autocomplete="off">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('patch'); ?>
                                    
                                    <div class="form-group mb-3">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                            </div>
                                            <input class="form-control" name="pregunta" id="preguntaEdit" placeholder="Pregunta" type="text" value="<?php echo e(old('pregunta')); ?>">
                                        </div>
                                    </div>
                                    <label class="form-control-label" for="input-tipo"><?php echo e(__('Clasificación de la Pregunta')); ?></label>
                                    <div class="form-group mb-3">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                            </div>
                                            <select id="input-tipo" class="form-control" name="tipo">
                                                <option selected value="">Clasificaci&oacute;n</option>
                                                <?php $__currentLoopData = $tipoPregunta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($tipo->tipo); ?>"><?php echo e($tipo->tipo); ?></option>    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                        </div>
                                    </div>
                                    <label class="form-control-label" for="input-respuestas"><?php echo e(__('Grupos de Respuestas')); ?></label>
                                    <div class="form-group mb-3">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                            </div>
                                            <select id="input-respuestas" class="form-control" name="respuestas">
                                                <option selected value="">Tipo de Respuestas</option>
                                                <?php $__currentLoopData = $grupoRs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($r->id_grupoRespuestas); ?>"><?php echo e($r->grupoRespuesta); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <label class="form-control-label" for="input-vigencia"><?php echo e(__('Año de Vigencia')); ?></label>
                                    <div class="form-group mb-3">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                            </div>
                                            <select id="input-vigencia" class="form-control" name="vigencia">
                                                <?php $anio = date('Y') ?>
                                                <option selected value="">Vigencia</option> 
                                                
                                                <?php for($i = 0; $i < 6; $i++): ?>
                                                    <option value="<?php echo e($anio+$i); ?>"><?php echo e($anio+$i); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <input type="hidden" id="idpreg" name="idpreg" value="">
                                    <div class="text-center">
                                        <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Actualizar')); ?></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    


        <?php $__env->startSection('script'); ?>
        <script>
            
         $('#modal-delete').on('show.bs.modal', function(event){
             var button = $(event.relatedTarget) //
             // console.log(button)
             var pregunta_id = button.attr('data-preguntaid')
             console.log(pregunta_id)
             var modal = $(this)
             // console.log(modal.find('.modal-body #nivel_id').val(alumn_id));
             modal.find('.modal-body #idpregunta').val(pregunta_id);
         } )



// 
        $('#modal-edit').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget)
            var idpregunta = button.attr('data-idpreg')
            // var idpregunta = button.data('idpreg')
            var pregunt = button.attr('data-preg')
            console.log(event.relatedTarget)
            var modal = $(this)
            modal.find('.modal-body #preguntaEdit').val(pregunt);
            modal.find('.modal-body #idpreg').val(idpregunta);
        })


        

</script>

        <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/evaluacionDocente/editarEvaluacion.blade.php ENDPATH**/ ?>