<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="pl-sm-4">
<div class="form-group">
    <label class="form-control-label" ><?php echo e(__('Name')); ?></label>
    <input type="text" name="name" id="input-name" class="form-control form-control-alternative" placeholder="<?php echo e(__('Name')); ?>" value="" required autofocus>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-cle\resources\views/alumnos/createAlumno.blade.php ENDPATH**/ ?>