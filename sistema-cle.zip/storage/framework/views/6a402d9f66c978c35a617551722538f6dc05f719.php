<!DOCTYPE html>
<html>

<head>
    <?php
        setlocale (LC_TIME, "es_ES");
    ?>
    <style>
        table,
        th,
        td {
            table-layout: fixed;
            border: 1px solid black;
            border-collapse: collapse;
            /* width: 250px; */
        }

        .sinborde {
            border: none;
        }

        .dias {
            border-top: 1px solid black;
            border-right: 1px solid black;
            border-bottom: 0px;
            border-left: 1px solid black;
        }

        .hora {
            border-top: 0px;
            border-right: 0px;
            border-bottom: 1px solid black;
            border-left: 1px solid black;
        }

        .aula {
            border-top: 0px;
            border-right: 1px solid black;
            border-bottom: 1px solid black;
            border-left: 0px;
        }

        .col-small {
            width: 13%;
            word-wrap: break-word;
            /* border-collapse: collapse; */
        }

        .col-med {
            width: 35%;
            word-wrap: break-word;
            /* border-collapse: collapse; */
        }

        .col-17 {
            width: 25%;
            word-wrap: break-word;
            /* border-collapse: collapse; */
        }

        .col-3 {
            width: 5%;
            word-wrap: break-word;
            /* border-collapse: collapse; */
        }
        #texto-dos {
            float: right;
            padding-right: 30%;
            line-height: 20%;
            /* text-transform: uppercase */
        }
    </style>

</head>

<body>
    <div align="center">
        <img src="<?php echo e(asset('argon')); ?>/img/brand/cabeceraSM.png" alt="cabecera" title="cabecera">
    </div>
    <br><br>

    <table style="width:100%; border:none;">
        <thead style="border:none;">
            <tr>
                <th scope="col" colspan="14" style="border:none;">ACTA DE CALIFICACIONES</th>
            </tr>
            <tr>
                <td scope="col" colspan="10" style="border:none;">DEPARTAMENTO: <strong>COORDINACI&Oacute;N DE LENGUAS EXTRANJERAS</strong> </td>
                <td scope="col" colspan="4" style="border:none;">FOLIO: <strong></strong></td>
            </tr>
            <tr>
                <td scope="col" colspan="10" style="border:none;">MATERIA: <strong><?php echo e($infoGrupo[0]->idioma); ?></strong></td>
                <td scope="col" colspan="4" style="border:none;">CLAVE: </td>
            </tr>
            <tr>
                <td scope="col" colspan="10" style="border:none;">PROFESOR: <strong><?php echo e($infoGrupo[0]->nombres); ?> <?php echo e($infoGrupo[0]->ap_paterno); ?> <?php if($infoGrupo[0]->ap_materno!=null): ?><?php echo e($infoGrupo[0]->ap_materno); ?> <?php endif; ?></strong></td>
                <td scope="col" colspan="4" style="border:none;">GRUPO: <strong><?php echo e($infoGrupo[0]->grupo); ?></strong> </td>
            </tr>
            <tr>
                <td scope="col" colspan="10" style="border:none;">PERIODO: <strong><?php echo e($infoGrupo[0]->descripcion); ?> <?php echo e($infoGrupo[0]->anio); ?></strong></td>
                <td scope="col" colspan="4" style="border:none;">ALUMNOS: <strong><?php echo e(count($alumnos_inscritos)); ?></strong></td>
            </tr>

        </thead>
        <tbody>
            <tr>
                <td scope="col" colspan="2" class="dias" align="center">LUNES</td>
                <td scope="col" colspan="2" class="dias" align="center">MARTES</td>
                <td scope="col" colspan="2" class="dias" align="center">MIERCOLES</td>
                <td scope="col" colspan="2" class="dias" align="center">JUEVES</td>
                <td scope="col" colspan="2" class="dias" align="center">VIERNES</td>
                <td scope="col" colspan="2" class="dias" align="center">SABADO</td>
                <td scope="col" colspan="2" class="dias" align="center">DOMINGO</td>
            </tr>
            <tr>
                <?php for($i = 0; $i < 7; $i++): ?> 
                    <td scope="col" class="hora" align="center">HORA</td>
                    <td scope="col" class="aula" align="center">AULA</td>
                <?php endfor; ?>

            </tr>
            <tr>
                <?php for($i = 0; $i < 5; $i++): ?> 
                    <td align="center"><?php if($infoGrupo[0]->modalidad=='Semanal'): ?> <?php echo e(substr($infoGrupo[0]->hora,0,-3)); ?><?php endif; ?></td>
                    <td align="center"><?php if($infoGrupo[0]->modalidad=='Semanal'): ?> <?php echo e($infoGrupo[0]->edificio); ?><?php echo e($infoGrupo[0]->aula); ?><?php endif; ?></td>
                <?php endfor; ?>

                <?php for($i = 0; $i < 2; $i++): ?> 
                    <td align="center"><?php if($infoGrupo[0]->modalidad=='Sabatino'): ?> <?php echo e(substr($infoGrupo[0]->hora,0,-3)); ?><?php endif; ?></td>
                    <td align="center"><?php if($infoGrupo[0]->modalidad=='Sabatino'): ?> <?php echo e($infoGrupo[0]->edificio); ?><?php echo e($infoGrupo[0]->aula); ?><?php endif; ?></td>
                <?php endfor; ?>


            </tr>
        </tbody>
    </table>
    <table style="width:100%" id="datatable">
        <thead class="thead-light">
            <tr>
                <th scope="col" class="col-3"><small>No.</small></th>
                <th scope="col" class="col-small"><small>No. DE <br>CONTROL</small></th>
                <th scope="col" class="col-med"><small>NOMBRE DEL ALUMNO</small></th>
                <th scope="col" class="col-17"><small>CARRERA</small></th>
                <th scope="col"><small>REP.</small></th>
                <th scope="col"><small>ORD.</small></th>
                <th scope="col"><small>COM.</small></th>
                <th scope="col"><small>ESP.</small></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i=1;
            ?>
            <?php $__currentLoopData = $alumnos_inscritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td>
                    <?php echo e($i); ?>

                </td>
                <td scope="row">
                    <?php echo e($alumno->num_control); ?>

                </td>
                <td scope="row">
                    <?php echo e($alumno->nombres); ?> <?php echo e($alumno->ap_paterno); ?> <?php if($alumno->ap_materno != null): ?> <?php echo e($alumno->ap_materno); ?> <?php endif; ?>
                </td>
                <td scope="row">
                    <?php if($alumno->carrera=='Ingeniería en Sistemas Computacionales'): ?>Ing. Sist. Com.
                    <?php else: ?>
                    <?php if($alumno->carrera=='Ingeniería en Gestión Empresarial'): ?>Ing. Gesti&oacute;n E.
                    <?php else: ?>
                    <?php if($alumno->carrera=='Licenciatura en Administración'): ?>Lic. Admin.
                    <?php else: ?>
                    <?php echo e($alumno->carrera); ?>

                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>

                </td>
                <td scope="row"></td>
                <td scope="row"><?php echo e($alumno->calif_f); ?></td>
                <td scope="row"></td>
                <td scope="row"></td>
            </tr>
            <?php
            $i++
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<br>
    <p>
        Este documento no es válido si tiene tachaduras o enmendaduras
        <br>
        Oaxaca de Ju&aacute;rez, Oax, a <?php echo e(strftime("%e")); ?> de <?php echo e(strftime("%B")); ?> de <?php echo e(strftime("%Y")); ?>															
        </p>
        <p id="texto-dos">
            Firma del Profesor:
        </p>
</body>

</html><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/pdf/actaCalificaciones.blade.php ENDPATH**/ ?>