<?php $__env->startSection('sidebar'); ?>
<?php
$usuarioactual = \Auth::user();
?>
<?php if($usuarioactual->tipo == 'coordinador'): ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('layouts.navbars.sidebarEstudiantes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="container-fluid m--t">
        <div class="text-right">
            <a href=" <?php echo e(route('verEstudiantes')); ?> " class="btn btn-outline-primary btn-sm mt-4">
                <span>
                    <i class="fas fa-reply"></i> &nbsp; Regresar
                </span>
            </a>
        </div>
        <div>
            <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <div class="card-body ">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>  
                </div>    
             
            <?php else: ?> 
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                     <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>                           
            <?php endif; ?>

        <form method="post" action="<?php echo e(route('actualizarEstudiante',$datos_alumno[0]->num_control)); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Personal')); ?></h6>
            
            <p class="text-muted">La informaci&oacute;n proporcionada en &eacute;sta p&aacute;gina web ser&aacute; utilizada para fines 
                    acad&eacute;micos y s&oacute;lo por la Coordinaci&oacute;n de Lenguas Extranjeras.</p>
            <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                   
                </div>
            <?php endif; ?>

            <div class="pl-lg-4">
                <div class="row">
                    <div class="col-md">
                        <label class="form-control-label" for="input-name"><?php echo e(__('Nombre(s)')); ?></label>
                        <input type="text" name="name" id="input-name" class="form-control" placeholder="" value="<?php echo e(old('name', $datos_alumno[0]->nombres)); ?>" required autofocus>
                    </div>
                    <div class="col-md">
                        <label class="form-control-label" for="input-apPaterno"><?php echo e(__('Apellido Paterno')); ?></label>
                        <input type="text" name="apPaterno" id="input-apPaterno" class="form-control" placeholder="" value="<?php echo e(old('apPaterno', $datos_alumno[0]->ap_paterno)); ?>" required autofocus>
                    </div>
                    <div class="col-md">
                        <label class="form-control-label" for="input-apMaterno"><?php echo e(__('Apellido Materno')); ?></label>
                        <input type="text" name="apMaterno" id="input-apMaterno" class="form-control" placeholder="" value="<?php echo e(old('apMaterno', $datos_alumno[0]->ap_materno)); ?>" autofocus>
                    </div>
                </div>
                
                <br>

                <div class="form-row">
                    <div class="form-group col-md-5">
                        <label class="form-control-label" for="input-curp"><?php echo e(__('CURP')); ?></label>
                        <input type="text" class="form-control" name="curp" id="input-curp" value="<?php echo e(old('curp', $datos_alumno[0]->curp)); ?>" onkeyup="this.value = this.value.toUpperCase();"
                        <?php if($usuarioactual->tipo != 'coordinador'): ?> readonly  <?php endif; ?>>
                    </div>
                    <div class="form-group col-md-2">
                        <label class="form-control-label" for="input-edad"><?php echo e(__('Edad')); ?></label>
                        <input type="text" class="form-control" name="edad" id="input-edad" value="<?php echo e(old('edad', $datos_alumno[0]->edad)); ?>">
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-sexo" ><?php echo e(__('Sexo')); ?></label>
                        <div class="row">            
                            <div class="custom-control custom-radio">
                                <input type="radio" id="sexof" name="sexo"  <?php if($datos_alumno[0]->sexo ='F'): ?> checked <?php endif; ?> value = <?php echo e(old('sexo',$datos_alumno[0]->sexo)); ?> class="custom-control-input">
                                <label class="custom-control-label" for="sexof">&nbsp&nbsp&nbsp&nbsp&nbspFemenino</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" id="sexom" name="sexo" <?php if($datos_alumno[0]->sexo ='M'): ?> checked <?php endif; ?> value = <?php echo e(old('sexo',$datos_alumno[0]->sexo)); ?> class="custom-control-input">
                                <label class="custom-control-label" for="sexom">&nbsp&nbsp&nbsp&nbsp&nbspMasculino</label>
                            </div>
                        </div>
                    </div>
                </div>
                <label class="form-control-label"><?php echo e(__('Dirección')); ?></label>
                <div class="row">
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-calle"><?php echo e(__('Calle')); ?></label>
                        <input type="text" name="calle" id="input-calle" class="form-control"  value="<?php echo e(old('calle', $datos_alumno[0]->calle)); ?>"  >
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-numero"><?php echo e(__('Número')); ?></label>
                        <input type="text" name="numero" id="input-numero" class="form-control" value="<?php echo e(old('numero', $datos_alumno[0]->numero)); ?>" >
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-colonia"><?php echo e(__('Colonia')); ?></label>
                        <input type="text" name="colonia" id="input-colonia" class="form-control" value="<?php echo e(old('colonia', $datos_alumno[0]->colonia)); ?>">
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-municipio"><?php echo e(__('Municipio')); ?></label>
                        <select id="input-municipio" class="form-control" name="municipio">
                            
                                <?php echo e($nm = App\Municipio::select('id','nombre_municipio')->where('id',$datos_alumno[0]->municipio)->pluck('nombre_municipio')); ?>

                            
                        <option selected <?php if($datos_alumno[0]->municipio != null): ?>value="<?php echo e(old('municipio', $datos_alumno[0]->municipio)); ?>" <?php endif; ?>>
                        <?php if($datos_alumno[0]->municipio != null): ?><?php echo e($nm[0]); ?> <?php endif; ?>
                        </option>
                        <?php $__currentLoopData = $nombres_municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mun); ?>"><?php echo e($mun); ?></option>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </select>                  
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-cp"><?php echo e(__('C. P.')); ?></label>
                    <input type="text" name="cp" id="input-cp" class="form-control" value="<?php echo e(old('cp', $datos_alumno[0]->cp)); ?>" >
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-telefono"><?php echo e(__('Teléfono')); ?></label>
                        <input type="text" name="telefono" id="input-telefono" class="form-control" placeholder="" value="<?php echo e(old('telefono', $datos_alumno[0]->telefono)); ?>">
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-email"><?php echo e(__('Email')); ?></label>
                        <input type="email" name="email" id="input-email" class="form-control form-control-alternative" placeholder="" value="<?php echo e(old('email',$email)); ?>" >
                    </div>
                </div>
        
        
            </div>

            <hr class="my-4" />
            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Escolar')); ?></h6>
            
            <div class="pl-lg-4">
            <div class="row">
                <div class="form-group col-md-4">
                    <label class="form-control-label" for="input-numControl"><?php echo e(__('Número de Control')); ?></label>
                    <input type="text" name="numControl" id="input-numControl" class="form-control" placeholder="" value="<?php echo e(old('numControl', $datos_alumno[0]->num_control)); ?>"
                    <?php if($usuarioactual->tipo != 'coordinador'): ?> readonly  <?php endif; ?> >
                </div>
                <div class="form-group col-md-6">
                    <label class="form-control-label" for="input-carrera"><?php echo e(__('Carrera')); ?></label>
                    <select id="input-carrera" class="form-control" name="carrera" value="<?php echo e(old('carrera', $datos_alumno[0]->carrera)); ?>">
                    <option selected value="<?php echo e(old('carrera', $datos_alumno[0]->carrera)); ?>"><?php echo e(old('carrera', $datos_alumno[0]->carrera)); ?></option>
                    <option value="Ingeniería Eléctrica"><?php echo e(__('Ing. Eléctrica')); ?></option>
                    <option value="Ingeniería Electrónica"><?php echo e(__('Ing. Electrónica')); ?></option>
                    <option value="Ingeniería Civil"><?php echo e(__('Ing. Civil')); ?></option>
                    <option value="Ingeniería Mecánica"><?php echo e(__('Ing. Mecánica')); ?></option>
                    <option value="Ingeniería Industrial"><?php echo e(__('Ing. Industrial')); ?></option>
                    <option value="Ingeniería Química"><?php echo e(__('Ing. Química')); ?></option>
                    <option value="Ingeniería en Gestión Empresarial"><?php echo e(__('Ing. Gestión Empresarial')); ?></option>
                    <option value="Ingeniería en Sistemas Computacionales"><?php echo e(__('Ing. Sistemas Computacionales')); ?></option>
                    <option value="Licenciatura en Administración"><?php echo e(__('Lic. Administración')); ?></option>
                    </select>
                </div>
                <div class="form-group col-md-2">
                        <label class="form-control-label" for="input-semestre"><?php echo e(__('Semestre')); ?></label>
                        <select  id="input-semestre" class="form-control" name="semestre">
                        <option selected value="<?php echo e(old('semestre', $datos_alumno[0]->semestre)); ?>"><?php echo e(old('semestre', $datos_alumno[0]->semestre)); ?></option>
                            <?php for($i = 1; $i <= 12; $i++): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e(($i)); ?></option>
                            <?php endfor; ?> 
                        </select>
                </div>
            </div>
            <div class="form-row" <?php if($usuarioactual->tipo == 'alumno'): ?> style="display:none;" <?php endif; ?>>
                <div class="form-group col-md-3">
                    <label class="form-control-label" for="examen"><?php echo e(__('Examen de Ubicación')); ?></label>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" id="examen" name="examen" onchange="comprobar(this);" value="true" class="custom-control-input" <?php if($datos_alumno[0]->nivel_inicial): ?> checked <?php endif; ?>>
                        <label class="custom-control-label" for="examen">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Realiz&oacute; examen</label>
                    </div>
                </div>
                <div class="form-group col-md-3" id="inicial" <?php if($datos_alumno[0]->nivel_inicial == null): ?> style="display:none" <?php endif; ?>>
                    <label class="form-control-label" for="input-nivel"><?php echo e(__('Nivel Donde Inicia')); ?></label>
                    <select id="input-nivel" class="form-control" name="nivel">
                        <option selected value="<?php echo e($datos_alumno[0]->nivel_inicial); ?>"><?php echo e($datos_alumno[0]->nivel_inicial); ?></option>
                            <?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($nivel->nivel); ?><?php echo e($nivel->modulo); ?>"><?php echo e($nivel->nivel); ?><?php echo e($nivel->modulo); ?>&nbsp;-&nbsp; <?php echo e($nivel->idioma); ?></option>                             
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>                  
                </div> 
            </div> 
            
            <hr class="my-4" />
            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información de Usuario')); ?></h6>
            <div class="form-group col-md-3">
                <label class="form-control-label" for="input-contrasenia"><?php echo e(__('Reestablecer Contraseña?*')); ?></label>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" id="input-contrasenia" name="contrasenia" onchange="comprobar2(this);" value="true" class="custom-control-input">
                    <label class="custom-control-label" for="input-contrasenia">o</label>
                </div>
            </div>
            <div id="reestablecer-contrasenia" style="display:none;">
                
                <div class="form-group col-xl-4">
                    <label class="form-control-label" for="input-password"><?php echo e(__('Nueva Contraseña')); ?></label>
                    <input type="password" name="password" id="input-password" class="form-control form-control-alternative" value="" >
                </div>
                <div class="form-group col-xl-4">
                    <label class="form-control-label" for="input-password-confirmation"><?php echo e(__('Confirmar Nueva Contraseña')); ?></label>
                    <input type="password" name="password_confirmation" id="input-password-confirmation" class="form-control form-control-alternative" value="" >
                </div>
            </div>
            <p class="text-muted">*El reestablecimiento de la contraseña no es obligatorio al ver o actualizar otro dato</p>          
        </div>
    </div>
        <script>
            function comprobar(obj)
            {   
                if (obj.checked){
                    document.getElementById('inicial').style.display = "";
                } else{
                    document.getElementById('inicial').style.display = "none";
                }     
            }

            function comprobar2(obj)
            {   
                if (obj.checked){
                    document.getElementById('reestablecer-contrasenia').style.display = "";
                } else{
                    document.getElementById('reestablecer-contrasenia').style.display = "none";
                }     
            }

        </script>

        <div class="text-center">
            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Actualizar')); ?></button>
        </div>
        </form>
        <br><br>
           <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/alumnos/editAlumno.blade.php ENDPATH**/ ?>