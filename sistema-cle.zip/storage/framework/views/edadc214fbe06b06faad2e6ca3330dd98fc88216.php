<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="header pb-5 pt-5 pt-lg-8 d-flex align-items-center" >
    </div>
        
<div class="container-fluid m--t col-md-6">
    <div class="card-body ">
        <?php if($errors->any()): ?>
            <p>No pudimos agregar los datos, <br> por favor, verifica la información</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>                            
        <?php endif; ?>
        <form role="form" method="post" action="<?php echo e(url('agregarNivel')); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <div class="form-group mb-3">
                <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                    </div>
                    <input class="form-control" name="nivel" placeholder="Nivel" type="text" value="<?php echo e(old('nivel')); ?>">
                </div>
            </div>
            <div class="form-group">
                <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                    </div>
                    <input class="form-control" name="modulo" placeholder="Modulo" type="text" value="<?php echo e(old('modulo')); ?>">
                </div>
            </div>
            <div class="form-group">
                <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                    </div>
                    <input class="form-control" name="idioma" placeholder="Idioma" type="text" value="<?php echo e(old('idioma')); ?>">
                </div>
            </div>
            <div class="text-center">
                <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Guardar')); ?></button>
            </div>
        </form>             
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/catalogos/niveles/createNivel.blade.php ENDPATH**/ ?>