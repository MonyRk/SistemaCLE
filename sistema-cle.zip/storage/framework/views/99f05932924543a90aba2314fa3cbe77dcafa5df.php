<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Resultados Evaluacion</title>

    <style>
        table,
        th,
        td {
            table-layout: fixed;
            border: 1px solid black;
            border-collapse: collapse;
        }

        .col-peq{
            width: 250px;
        }
    </style>

    
<script type="text/javascript" src="http://www.gstatic.com/charts/loader.js"></script>
<?php
$k=0; $promedio=0; $promedio_final=0; $p=0; $promedios=""; $clasificacion_preguntas="";
?>
<?php $__currentLoopData = $datos_clasificacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $datos_respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
            $total = 0;
            $total = $resultados[$k]*$respuesta->valor 
            ?>
        <?php
            $promedio = $promedio + $total;
        ?>
        <?php $k++ ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php
        $p = $promedio/5;
        $promedios = $promedios.','.$p;
        $clasificacion_preguntas = $clasificacion_preguntas.','.$clasificacion->clasificacion;
        $promedio_final= $promedio_final+($promedio/5);
        $promedio=0;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php
$clasificacion_preguntas = substr($clasificacion_preguntas,1);
$promedios = substr($promedios,1);
?>

<script>

        google.charts.load('current', {packages: ['corechart', 'bar']});
            google.charts.setOnLoadCallback(drawStacked);
    
            function drawStacked() {
                var $datosClasificacion = "<?php echo $clasificacion_preguntas ?>"
                var $clasificacion = $datosClasificacion.split(",");
    
                var $datosPromedios = "<?php echo $promedios ?>"
                var $dpromedios = $datosPromedios.split(",");
    
                var data = google.visualization.arrayToDataTable([
                    ['Elements','Details', { role: 'style' },{ role: 'annotation' }],
                    ['Enfoque de Enseñanza',parseInt($dpromedios[0],10), 'color: #FF6384',$datos[0]],
                    ['Clima Afectivo',parseInt($dpromedios[1],10), 'color: #36A2EB',$datos[1]],            
                    ['Proceso de Enseñanza', parseInt($dpromedios[2],10),'color: #FFCE56',$datos[2]],      
                    ['Estrategias de Retroalimentacion',parseInt($dpromedios[3],10), 'color: #FFCE56',$datos[8] ] // CSS-style declaration
                ]);
                var options = {
                    title: 'Estudiantes por Carrera',
                    hAxis: {
                    title: 'Carreras',
                    },
                    vAxis: {
                    title: 'Número de Estudiantes'
                    }
                };
    
                var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
                chart.draw(data, options);
            }
    
    
    
    </script>
    
</head>

<body onload="init()">
    <div align="center">
        <img src="<?php echo e(asset('argon')); ?>/img/brand/cabeceraSM.png" alt="cabecera" title="cabecera">
    </div>
    
    <div align="center" >
        <div class="col-lg col-md">
            <h6 class="text-dark">Resultados Evaluaci&oacute;n Docente Periodo <?php echo e($periodo[0]->descripcion); ?> <?php echo e($periodo[0]->anio); ?></h6>
            <h4 class="text-dark"><?php echo e($docente[0]->nombres); ?> <?php echo e($docente[0]->ap_paterno); ?> <?php if( $docente[0]->ap_materno ): ?> <?php echo e($docente[0]->ap_materno); ?> <?php endif; ?></h4>
        </div>
    </div>
        
    <table id="tabledata" style="width:80%" align="center">
        <thead>
            <tr>
                <th>Clasificaci&oacute;n </th>
                <th class="col-peq">Promedio</th>
            </tr>
        </thead>
        <tbody> 
            
            <?php $__currentLoopData = $datos_clasificacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($clasificacion->clasificacion); ?>

                    </td>
                    <?php $__currentLoopData = $datos_respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                            $total = 0;
                            $total = $resultados[$k]*$respuesta->valor 
                            ?>
                        <?php $k++ ?>
                        <?php
                        $promedio = $promedio + $total;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $p = $promedio/5;
                        $promedios = $promedios.','.$p;
                        $clasificacion_preguntas = $clasificacion_preguntas.','.$clasificacion->clasificacion;
                        $promedio_final= $promedio_final+($promedio/5);
                        $promedio=0;
                    ?>
                    <td align="center"><?php echo e($p); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    
<br><br><br>
    <div id="chart_div" align="center"></div>

</body>



    
        <?php
            $rango_desempeño = $datos_respuesta[0]->valor/3
        ?>
                
       
        <div class="col-lg col-md">
            <h5>El promedio final de la Evaluación Docente es de: <?php echo e($promedio_final/count($datos_clasificacion)); ?> <br>
                <br> Indicador que el desempeño es:
                <?php if($promedio_final/count($datos_clasificacion) <= $rango_desempeño ): ?>
                    NO ACEPTABLE
                <?php endif; ?>
                <?php if($promedio_final/count($datos_clasificacion) > $rango_desempeño && $promedio_final/count($datos_clasificacion) <= $rango_desempeño*2 ): ?>
                    ACEPTABLE
                <?php endif; ?>
                <?php if($promedio_final/count($datos_clasificacion) > $rango_desempeño*2 && $promedio_final/count($datos_clasificacion) <= $rango_desempeño*3 ): ?>
                    BUENO
                <?php endif; ?>
            </h5>
    </div>

<?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/pdf/resultadosEvaluacionpdf.blade.php ENDPATH**/ ?>