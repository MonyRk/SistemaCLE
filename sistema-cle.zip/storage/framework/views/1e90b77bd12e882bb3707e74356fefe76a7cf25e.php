<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

     
     <div class="container-fluid m--t">
        <div class="text-right">
            <a href="<?php echo e(route('inicio')); ?> " class="btn btn-outline-primary btn-sm mt-4">
                <span>
                    <i class="fas fa-reply"></i> &nbsp; Regresar
                </span>
            </a>
        </div>
        <div class="row">
            <!-- espacio de busqueda-->
            <div class="col-md">
                <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md">
                <div class="">
                    <form action="<?php echo e(route('buscarDocente')); ?>" method="GET" class="navbar-search navbar-search-dark form-inline mr-5 d-none d-md-flex ml-lg-9"  style="margin-top: 15px" >
                        <div class="form-group mb-0">
                            <div class="input-group input-group-alternative">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                </div>
                                <input name ="buscar"class="form-control" placeholder="Buscar" type="text">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
          
            <div class="col-xl">
                <!-- header de la tabla-->
                <div class="col-xl">
                    <div class="card shadow ">
                        <div class="card-header border-3">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h4 class="mb-0">Datos de los Docentes</h4>
                                </div>
                                <div class="col text-right">
                                    <a href="<?php echo e(url("/agregarDocente")); ?>" class="btn btn-sm btn-gray">Agregar
                                        <i class="fas fa-user-plus"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <!-- Projects table -->
                            <table class="table align-items-center table-flush th">
                                <thead class="thead-light">
                                    <tr> 
                                        
                                        <th scope="col">Nombre</th>
                                        <th scope="col">Grado de <br> Estudios</th>
                                        <th scope="col">Estatus</th>
                                        <th scope="col">Editar</th>
                                        <th scope="col">Eliminar</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $docentes_en_grupo = App\Grupo::whereNotNull('docente')->distinct()->pluck('docente');
                                    ?>
                                    <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <th>
                                            <a href="<?php echo e(route('verInfoDocente',$docente->id_docente)); ?>" class="text-dark"><?php echo e($docente->nombres); ?> <?php echo e($docente->ap_paterno); ?> <?php echo e($docente->ap_materno); ?></a>
                                        </th>                                      
                                        <td name=""><?php echo e($docente->grado_estudios); ?></td>
                                        <td>
                                            <?php echo e($docente->estatus); ?>

                                        </td>
                                        <?php
                                            $docente_en_grupo = App\Grupo::where('docente',$docente->id_docente)->get();
                                        ?>
                                        <td class="text-center"> 
                                                <a href="docentes/<?php echo e($docente->id_docente); ?>/editar" class="text-primary"><i class="fas fa-edit"></i></a>
                                            </td>
                                        <?php if($docente_en_grupo->isEmpty()): ?>
                                            
                                            <td class="text-center">
                                                <a href="" id="docenteid" class="text-danger" data-docenteid="<?php echo e($docente->id_docente); ?>" data-toggle="modal" data-target="#modal-notification" ><i class="far fa-trash-alt"></i></a>
                                            </td>
                                        <?php else: ?>
                                            <td colspan="" class="text-center">
                                                <a href="" class="text-primary" data-toggle="modal" data-target="#modal-notification2" ><i class="far fa-question-circle"></i></a>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo e($docentes->links()); ?>

                    </div>
                </div>
            </div>

        </div>
    
        <div class="col-md-4">
            <div class="modal fade" id="modal-notification" tabindex="-1" role="dialog" aria-labelledby="modal-notification" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-" role="document">
                    <div class="modal-content bg-gradient-white">
                        
                        <div class="modal-header">
                            <h6 class="modal-title" id="modal-title-notification">¡Espera!</h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                            
                        </div>
                        <form action="<?php echo e(route('eliminarDocente','test')); ?>" method="POST" class="delete" id="deleteForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <div class="modal-body">
                            
                            <div class="py-3 text-center">
                                    <i class="fas fa-times fa-3x" style="color:#CD5C5C;"></i>
                                <h4 class="heading mt-4">¡Da tu confirmaci&oacute;n para Eliminar!</h4>
                                <p>¿Realmente deseas eliminar los datos del docente?</p>
                                <input type="hidden" name="docente_id" id="docente_id" value="">
                            </div>
                            
                        </div>
                        
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-outline-danger">S&iacute;, Eliminar</button>
                            <button type="button" class="btn btn-link text-gray ml-auto" data-dismiss="modal">No, Cambi&eacute; de opinion</button> 
                        </div>
                        </form>
                    </div>
                </div>
            </div>
                </div>
    



                 
            <div class="col-md-4">
                    <div class="modal fade" id="modal-notification2" tabindex="-1" role="dialog" aria-labelledby="modal-notification" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-" role="document">
                            <div class="modal-content">
                                
                                <div class="modal-header">
                                    <h6 class="modal-title" id="modal-title-notification">¡Espera!</h6>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    
                                </div>
                               
                                <div class="modal-body">
                                    
                                    <div class="py-3 text-center">
                                            <i class="fas fa-exclamation fa-3x text-warning" style=""></i>
                            <h4 class="heading mt-4">Los datos de este docente no se puede Eliminar</h4>
                            <p>Los datos de este docente estan asociados a uno o más grupos, por esta razón no se puede eliminar.</p>
                                        <input type="hidden" name="grupo_id" id="grupo_id" value="">
                                    </div>
                                    
                                </div>
                                
                                <div class="modal-footer">
                                    
                                    <button type="button" class="btn btn-outline-warning ml-auto" data-dismiss="modal">Entendido</button> 
                                </div>
                            </div>
                        </div>
                    </div>
            
                        </div>
    
               <?php $__env->startSection('script'); ?>
               <script>
                $('#modal-notification').on('show.bs.modal', function(event){
                    var button = $(event.relatedTarget) //
                    var docent_id = button.attr('data-docenteid')
                    var modal = $(this)
                    modal.find('.modal-body #docente_id').val(docent_id);
                } )
                </script>
               <?php $__env->stopSection(); ?>

               <br><br>
               <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
 
</div>
            

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/docentes/docentes.blade.php ENDPATH**/ ?>