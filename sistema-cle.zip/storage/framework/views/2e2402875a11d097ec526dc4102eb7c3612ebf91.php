<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl">
        <div class="copyright text-center text-xl-center text-muted">
             <a href="/sistema-cle/public/" class="font-weight-bold ml-1" target="_blank">
                 Coodinación de Lenguas Extranjeras
                </a> 
            <a href="http://www.oaxaca.tecnm.mx/web/" class="font-weight ml-1" target="_blank">
                <br> Tecnológico Nacional de México / Instituto Tecnológico de Oaxaca 
                <br> Avenida Ing. Víctor Bravo Ahuja No. 125 Esquina Calzada Tecnológico, C.P. 68030 
                <br> Correo-e: tec_oax@itoaxaca.edu.mx - Tel: (951) 501 50 16 
               <br>  &copy; <?php echo e(now()->year); ?>

            </a>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sistema-cle\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>