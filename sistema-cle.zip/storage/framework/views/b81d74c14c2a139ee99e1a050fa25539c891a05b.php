<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="container-fluid m--t">
        <div class="text-right">
            <a href=" <?php echo $__env->yieldContent('regresar'); ?> " class="btn btn-outline-primary btn-sm mt-4">
                <span>
                    <i class="fas fa-reply"></i> &nbsp; Regresar
                </span>
            </a>
        </div>
<h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Personal')); ?></h6>
<div>
    <div class="row">
    <div class="col-xl col-lg-6">
        <div class="card card-stats mb-4 mb-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <span class="card-tittle"><?php echo e(__('Nombre: ')); ?></span>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="">
                        <p class="card-text font-weight-bold"><?php echo e($datos[0]->nombres); ?> <?php echo e($datos[0]->ap_paterno); ?> <?php echo e($datos[0]->ap_materno); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl col-lg-6">
        <div class="card card-stats mb-4 mb-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <span class="card-tittle"><?php echo e(__('CURP: ')); ?></span>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="">
                        <p class="card-text font-weight-bold"><?php echo e($datos[0]->curp); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl col-lg-6">
        <div class="card card-stats mb-4 mb-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <span class="card-title"><?php echo e(__('Dirección: ')); ?></span>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="">  
                        <p class="card-text font-weight-bold">
                            <?php if($datos[0]->calle != null): ?> <?php echo e($datos[0]->calle); ?>  <?php endif; ?>
                            <?php if($datos[0]->numero != null): ?> <?php echo e($datos[0]->numero); ?>  <?php endif; ?>
                            <?php if($datos[0]->colonia != null): ?> <?php echo e($datos[0]->colonia); ?>  <?php endif; ?>
                            <?php if($municipio->isNotEmpty()): ?> <?php echo e($municipio[0]); ?>  <?php endif; ?>
                            <?php if($datos[0]->cp != null): ?> <?php echo e($datos[0]->cp); ?>  <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl col-lg-6">
        <div class="card card-stats mb-4 mb-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <span class="card-title"><?php echo e(__('Teléfono: ')); ?></span>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="">
                        <p class="card-text font-weight-bold">
                            <?php if($datos[0]->telefono != null): ?> <?php echo e($datos[0]->telefono); ?>  <?php endif; ?>
                        <p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>       
<div class="row">
    <div class="col-xl-6 col-lg-6">
        <div class="card card-stats mb-4 mb-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <span class="card-title"><?php echo e(__('Email: ')); ?></span>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="">
                        <p class="card-text font-weight-bold">
                            <?php if($datos[0]->email != null): ?> <?php echo e($datos[0]->email); ?>  <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl col-lg-6">
        <div class="card card-stats mb-4 mb-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <span class="card-title"><?php echo e(__('Edad: ')); ?></span>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="">
                        <p class="card-text font-weight-bold"><?php echo e($datos[0]->edad); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl col-lg-6">
        <div class="card card-stats mb-4 mb-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <span class="card-title"><?php echo e(__('Sexo: ')); ?></span>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="">
                        <p class="card-text font-weight-bold">
                            <?php if($datos[0]->sexo ='F'): ?>
                                <?php echo e(__('Femenino')); ?>

                            <?php else: ?>
                                <?php echo e(__('Masculino')); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div>
    <?php echo $__env->yieldContent('informacion'); ?>
</div>

<br><br>
           <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/viewsBase/show.blade.php ENDPATH**/ ?>