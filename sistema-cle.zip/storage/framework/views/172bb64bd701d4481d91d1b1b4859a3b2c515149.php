<?php $__env->startSection('sidebar'); ?>
<?php
$usuarioactual = \Auth::user();
?>
<?php if($usuarioactual->tipo == 'coordinador'): ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('layouts.navbars.sidebarEstudiantes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    use Carbon\Carbon;
?>
<div class="container-fluid m--t">
    <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center" >
        <div class="col-lg col-md">
            <h4 class="text-dark">Pagos</h4>
        </div>
    </div>
    <div class="card-body">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="text-right">
        
        <a href="<?php echo e(back()); ?>" class="btn btn-outline-primary btn-sm mt-4">
            <span>
                <i class="fas fa-reply"></i> &nbsp; Regresar
            </span>
        </a>
    </div>
    <form action="<?php echo e(route('guardarVerificados')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="row mt-3">
            <div class="col-xl">
                <div class="col-xl">
                    <div class="card shadow ">
                        <div class="card-header border-3">
                            <div class="row align-items-center">
                                <div class="col">
                                    Estudiante: <strong class="mb-0"><?php echo e($pagos[0]->nombres); ?> <?php echo e($pagos[0]->ap_paterno); ?> <?php if($pagos[0]->ap_materno!=null): ?> <?php echo e($pagos[0]->ap_materno); ?> <?php endif; ?></strong>                           
                                </div>
                                <div class="col">N&uacute;mero de Control: <strong><?php echo e($pagos[0]->num_control); ?></strong></div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush th" id="datatable">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Folio de Pago</th>
                                        <th scope="col">Monto de Pago</th>
                                        <th scope="col">Fecha</th>
                                        <?php if($usuarioactual->tipo == 'coordinador'): ?>
                                            <th scope="col">Verificar</th>
                                        <?php else: ?>
                                            <th scope="col">Estatus</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($pago->folio_pago); ?>

                                            </td>
                                            <td>
                                                <?php echo e($pago->monto_pago); ?>

                                            </td>
                                            <td>
                                                <?php echo e(date('d-m-Y', strtotime($pago->fecha))); ?>

                                            </td>
                                            <td>
                                                <?php if($usuarioactual->tipo == 'coordinador'): ?>
                                                    <?php if($pago->pago_verificado == true): ?>
                                                    <p class="text-success"><i class="fas fa-check"></i> Verificado</p>
                                                    <?php else: ?>
                                                        <div class="custom-control custom-control-alternative custom-checkbox">
                                                            <input class="custom-control-input" id="<?php echo e($pago->folio_pago); ?>" name="verificado[]" type="checkbox" value="<?php echo e($pago->num_inscripcion); ?>">
                                                            <label class="custom-control-label" for="<?php echo e($pago->folio_pago); ?>">o</label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($pago->pago_verificado == true): ?>
                                                        <p class="text-success"><i class="fas fa-check"></i> Verificado</p>
                                                    <?php else: ?>
                                                        <p class="text-danger"><i class="fas fa-times"></i> No Verificado</p>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center" <?php if($usuarioactual->tipo != 'coordinador'): ?> style = "display:none;" <?php endif; ?>>
            <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Guardar')); ?></button>
        </div>
    </form>
    <br><br>
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/pagos/pagos.blade.php ENDPATH**/ ?>