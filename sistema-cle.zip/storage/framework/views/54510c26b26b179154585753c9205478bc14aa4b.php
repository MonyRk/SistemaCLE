<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid m--t">
            <div class="text-right">
                    <a href="<?php echo e(route('verGrupos')); ?> " class="btn btn-outline-primary btn-sm mt-4">
                        <span>
                            <i class="fas fa-reply"></i> &nbsp; Regresar
                        </span>
                    </a>
                </div>
        <div class="card-body">
            <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>  
                </div> 
            <?php endif; ?>
        </div>

        <form method="post" action="<?php echo e(route('agregarGrupo')); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Principal')); ?></h6>
            
            <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                   
                </div>
            <?php endif; ?>

            <div class="pl-lg-4">
                <div class="row">
                    <div class="col-md">
                        <label class="form-control-label" for="input-name"><?php echo e(__('Nombre del Grupo')); ?></label>
                        <input type="text" name="name" id="input-name" class="form-control" value="<?php echo e(old('name',$data['name'])); ?>" >
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-modalidad"><?php echo e(__('Modalidad')); ?></label>
                        <select id="input-modalidad" class="form-control" name="modalidad">
                            <option selected></option>
                                <option value="Semanal"><?php echo e(__('Semanal')); ?></option>
                                <option value="Sabatino"><?php echo e(__('Sabatino')); ?></option>
                        </select>                  
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-nivel"><?php echo e(__('Nivel')); ?></label>
                        <select id="input-nivel" class="form-control" name="nivel">
                            <option selected></option>
                                <?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($nivel->id_nivel); ?>"><?php echo e($nivel->nivel); ?><?php echo e($nivel->modulo); ?>&nbsp;-&nbsp; <?php echo e($nivel->idioma); ?></option>                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                  
                    </div>
                                   
                </div>
                <div class="row">
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-aula"><?php echo e(__('Aula')); ?></label>
                        <select id="input-aula" class="form-control" name="aula">
                            <option selected></option>
                                <?php $__currentLoopData = $aulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($aula->id_aula); ?>"><?php echo e($aula->edificio); ?><?php echo e($aula->num_aula); ?></option>                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                  
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-hora"><?php echo e(__('Hora')); ?></label>
                        <select id="input-hora" class="form-control" name="hora"> 
                        </select>                  
                    </div>
                    <div class="form-group col-md-6">
                        <label class="form-control-label" for="input-nivel"><?php echo e(__('Docente')); ?></label>
                        <select id="input-docente" class="form-control" name="docente">
                            <option selected></option>
                                <?php $__currentLoopData = $maestros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maestro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($maestro->id_docente); ?>"><?php echo e($maestro->nombres); ?> <?php echo e($maestro->ap_paterno); ?> <?php echo e($maestro->ap_materno); ?></option>                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                  
                    </div>
                </div>

                <div class="form-row">
                      
                    <div class="col-md">
                        <label class="form-control-label" for="input-cupo"><?php echo e(__('Límite de Estudiantes en el grupo')); ?></label>
                        <input type="text" name="cupo" id="input-cupo" class="form-control" placeholder="" value="<?php echo e(old('cupo',$data['cupo'])); ?>" >
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-periodo"><?php echo e(__('Periodo')); ?></label>
                        <select id="input-periodo" class="form-control" name="periodo">
                            <option selected></option>
                                <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($periodo->id_periodo); ?>"><?php echo e($periodo->descripcion); ?> <?php echo e($periodo->anio); ?></option>                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                  
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Guardar')); ?></button>
                </div>
            </div>
        </form>
        <br><br>
        <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var $jq = jQuery.noConflict();
    $jq(document).ready(function(){
        $jq('#input-aula').on('change',function(){
            var aula_id = $jq(this).val();
            if ($jq.trim(aula_id) != ''){
                $jq.get('aulas',{id_aula: aula_id},function(aulas){
                    $jq('#input-hora').empty();
                    $jq('#input-hora').append("<option value=''></option>");
                    $jq.each(aulas, function(index, value){ 
                        // console.log(index,value);
                        for (let i = 0; i < 14; i++) {
                            if (value[i] != null) {
                                $jq('#input-hora').append("<option value='"+ i +"'>"+ value[i] +"</option>");
                            }
                        }
                    });
                });
            }
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/grupos/grupo.blade.php ENDPATH**/ ?>