<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
     <div class="container-fluid">
         <div class="row">
            <!-- espacio de busqueda-->
            <div class="col-sm-6"></div>
            <div class="col-sm-6">
                <div class="">
                        <form class="navbar-search navbar-search-dark form-inline mr-5 d-none d-md-flex ml-lg-9"  aling="right" >
                            <div class="form-group mb-0">
                                <div class="form-inline my-2 my-lg-0 input-group input-group-alternative">
                                    
                                    <input class="form-control2" placeholder="Buscar" type="text">
                                    <div class="input-group-prepend">
                                            <span class="input-group-textt"><i class="fas fa-search"></i></span>
                                        </div>
                                </div>
                            </div>
                        </form>

                </div>
            </div>

         </div>
            <div class="row">
                <!-- filtros de busqueda -->
              <div class="col-xl-4">
                    Nivel <br> 
                  <div class="row">     <!-- se deben sustituir los checkbox por cada nivel que haya -->       
                    <div class="col">
                        <div class="custom-control custom-control-alternative custom-checkbox mb-3">
                            <input class="custom-control-input" id="customCheck5" type="checkbox">
                            <label class="custom-control-label" for="customCheck5">1</label>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-check form-check-inline custom-control custom-control-alternative custom-checkbox mb-3">
                            <input class="custom-control-input" id="customCheck7" type="checkbox">
                            <label class="custom-control-label" for="customCheck7">3</label>
                        </div>
                      </div>

                  </div>
              </div>

              <div class="col-xl-8">
                <!-- header de la tabla-->
                <div class="col-xl">
                    <div class="card shadow ">
                        <div class="card-header border-3">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="mb-0">Datos de Alumnos</h3>
                                </div>
                                <div class="col text-right">
                                    <a href="#!" class="btn btn-sm btn-primary">See all</a>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <!-- Projects table -->
                            <table class="table align-items-center table-flush th">
                                <thead class="thead-light">
                                    <tr> <!-- se debe hacer una consulta para obtener las cabeceras de la tabla alumnos-->
                                        <th scope="col">Nombre</th>
                                        <th scope="col">Numero de control</th>
                                        <th scope="col"> curso</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">
                                            Facebook
                                        </th>
                                        <td>
                                            1,480
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="mr-2">60%</span>
                                                <div>
                                                    <div class="progress">
                                                    <div class="progress-bar bg-gradient-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            Facebook
                                        </th>
                                        <td>
                                            5,480
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="mr-2">70%</span>
                                                <div>
                                                    <div class="progress">
                                                    <div class="progress-bar bg-gradient-success" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            Google
                                        </th>
                                        <td>
                                            4,807
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="mr-2">80%</span>
                                                <div>
                                                    <div class="progress">
                                                    <div class="progress-bar bg-gradient-primary" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            Instagram
                                        </th>
                                        <td>
                                            3,678
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="mr-2">75%</span>
                                                <div>
                                                    <div class="progress">
                                                        <div class="progress-bar bg-gradient-info" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 75%;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            twitter
                                        </th>
                                        <td>
                                            2,645
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="mr-2">30%</span>
                                                <div>
                                                    <div class="progress">
                                                    <div class="progress-bar bg-gradient-warning" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width: 30%;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            
        </div>
<?php $__env->stopSection(); ?>



 
</div>
            
</div>
</div>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-cle\resources\views/alumnos/create.blade.php ENDPATH**/ ?>