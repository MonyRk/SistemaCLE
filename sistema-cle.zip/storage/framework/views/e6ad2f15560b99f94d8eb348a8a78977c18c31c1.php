<?php $__env->startSection('sidebar'); ?>
<?php
$usuarioactual = \Auth::user();
?>
<?php if($usuarioactual->tipo == 'coordinador'): ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if($usuarioactual->tipo == 'docente'): ?>
<?php echo $__env->make('layouts.navbars.sidebarDocentes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<style>
    .col-med {
        width: 50%;
        word-wrap: break-word;
    }
    .padre {
  background-color: #fafafa;
  margin: 1rem;
  padding: 1rem;
  border: 2px solid #ccc;
  /* IMPORTANTE */
  text-align: center;
}
</style>
<div class="container-fluid m--t">
    <div class="card-body">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>  
            </div> 
        <?php endif; ?>
    </div> 
    <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center" >
        <div class="col-lg col-md">
            <h6 class="text-dark">Resultados Evaluaci&oacute;n Docente Periodo <?php echo e($periodo[0]->descripcion); ?> <?php echo e($periodo[0]->anio); ?></h6>
            <h4 class="text-dark"><?php echo e($docente[0]->nombres); ?> <?php echo e($docente[0]->ap_paterno); ?> <?php if( $docente[0]->ap_materno ): ?> <?php echo e($docente[0]->ap_materno); ?> <?php endif; ?></h4>
        </div>
    </div>
    <div class="text-right mb-2">
        <a href=" <?php echo e(route('inicio')); ?> " class="btn btn-outline-primary btn-sm mt-3">
            <span>
                <i class="fas fa-reply"></i> &nbsp; Regresar
            </span>
        </a>
    </div> 
    <div class="row">    
        <div class="col-xl">
            <div class="col-xl">
                <div class="card shadow ">
                    <div class="table-responsive">
                        <table id="tabledata" class="table align-items-center table-flush th">
                            <thead class="thead-light">
                                <tr class="card-header">
                                    <th></th>
                                    <th class="text col-med" rowspan="2">Clasificaci&oacute;n </th>
                                    
                                    <th rowspan="2">Promedio</th>
                                </tr>
                                
                            </thead>
                            <tbody> <?php $k=0; $promedio=0; $promedio_final=0; $p=0; $promedios=""; $clasificacion_preguntas="";?>
                                <?php $__currentLoopData = $datos_clasificacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th></th>
                                        <th>
                                            <?php echo e($clasificacion->clasificacion); ?>

                                        </th>
                                        <?php $__currentLoopData = $datos_respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php 
                                                $total = 0;
                                                $total = $resultados[$k]*$respuesta->valor 
                                                ?>
                                            <?php $k++ ?>
                                            <?php
                                            $promedio = $promedio + $total;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $p = $promedio/5;
                                            $promedios = $promedios.','.$p;
                                            $clasificacion_preguntas = $clasificacion_preguntas.','.$clasificacion->clasificacion;
                                            $promedio_final= $promedio_final+($promedio/5);
                                            $promedio=0;
                                        ?>
                                        <th><?php echo e($p); ?></th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
            
    <div class="row mt-6">
        <div class="col-xl-12">
            <div class="card shadow">
                <div class="card-header bg-transparent">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="mb-0">Resultados Evaluaci&oacute;n</h3>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Chart -->
                    <div class="chart">
                        <canvas id="chart-orders4" width="800" height="00" class="chart-canvas"></canvas>

                    </div>
                </div>
            </div>
        </div>
        <?php
            $rango_desempeño = $datos_respuesta[0]->valor/3
        ?>
                
        <?php $__env->startSection('script'); ?>
            <?php
                $clasificacion_preguntas = substr($clasificacion_preguntas,1);
                $promedios = substr($promedios,1);
            ?>
            
            <script>
                    var OrdersChart = (function() {
                    // Variables
                    var $datosClasificacion = "<?php echo $clasificacion_preguntas ?>"
                    var $clasificacion = $datosClasificacion.split(",");

                    var $datosPromedios = "<?php echo $promedios ?>"
                    var $dpromedios = $datosPromedios.split(",");
            
                    var $chart = $('#chart-orders4');
                    var $ordersSelect = $('[name="ordersSelect"]');
                    // Methods
                    // Init chart
                    function initChart($chart) {
                        // Create chart
                        var ordersChart = new Chart($chart, {
                            type: 'bar',
                            options: {
                                scales: {
                                    yAxes: [{
                                        ticks: {
                                            callback: function(value) {
                                                if (!(value % 10)) {
                                                    //return '$' + value + 'k'
                                                    return value
                                                }
                                            }
                                        }
                                    }]
                                },
                                tooltips: {
                                    callbacks: {
                                        label: function(item, data) {
                                            var label = data.datasets[item.datasetIndex].label || '';
                                            var yLabel = item.yLabel;
                                            var content = '';
            
                                            if (data.datasets.length > 1) {
                                                content += '<span class="popover-body-label mr-auto">' + label + '</span>';
                                            }
            
                                            content += '<span class="popover-body-value">' + yLabel + '</span>';
            
                                            return content;
                                        }
                                    }
                                }
                            },
                            data: {
                                labels: $clasificacion,
                                datasets: [{
                                    label: 'Clas.',
                                    data: $dpromedios,
                                    backgroundColor: [
                                        'rgba(255, 99, 132, 0.2)',
                                        'rgba(54, 162, 235, 0.2)',
                                        'rgba(255, 206, 86, 0.2)',
                                        'rgba(75, 192, 192, 0.2)'
                                    ],
                                    borderColor: [
                                        'rgba(255, 99, 132, 1)',
                                        'rgba(54, 162, 235, 1)',
                                        'rgba(255, 206, 86, 1)',
                                        'rgba(75, 192, 192, 1)'
                                    ],
                                    borderWidth: 1
                                }]
                            }
                        });
                        // Save to jQuery object
                        $chart.data('chart', ordersChart);
                    }
                    // Init chart
                    if ($chart.length) {
                        initChart($chart);
                    }
                })();
            </script>
        <?php $__env->stopSection(); ?>
        
    </div>
    <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center mt-6" >
        <div class="col-lg col-md">
            <h5>El promedio final de la Evaluación Docente es de: <?php echo e($promedio_final/count($datos_clasificacion)); ?> <br>
                <br> Indicador que el desempeño es:
                <?php if($promedio_final/count($datos_clasificacion) <= $rango_desempeño ): ?>
                    NO ACEPTABLE
                <?php endif; ?>
                <?php if($promedio_final/count($datos_clasificacion) > $rango_desempeño && $promedio_final/count($datos_clasificacion) <= $rango_desempeño*2 ): ?>
                    ACEPTABLE
                <?php endif; ?>
                <?php if($promedio_final/count($datos_clasificacion) > $rango_desempeño*2 && $promedio_final/count($datos_clasificacion) <= $rango_desempeño*3 ): ?>
                    BUENO
                <?php endif; ?>
            </h5>
        </div>
    </div>
    
</div>
<br><br>
<?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/evaluacionDocente/resultados.blade.php ENDPATH**/ ?>