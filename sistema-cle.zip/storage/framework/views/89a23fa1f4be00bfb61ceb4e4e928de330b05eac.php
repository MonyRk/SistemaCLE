<?php $__env->startSection('sidebar'); ?>
<?php
$usuarioactual = \Auth::user();
?>
<?php if($usuarioactual->tipo == 'coordinador'): ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if($usuarioactual->tipo == 'alumno'): ?>
<?php echo $__env->make('layouts.navbars.sidebarEstudiantes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if($usuarioactual->tipo == 'docente'): ?>
<?php echo $__env->make('layouts.navbars.sidebarDocentes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid m--t">
    <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center">
        <div class="col-lg col-md">
            <h4 class="text-dark">Evaluaci&oacute;n Docente</h4>
        </div>
    </div>
    <div class="card-body">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>

    <div class="text-right">
        <a href="<?php echo e(route('inicio')); ?>" class="btn btn-outline-primary btn-sm mt--3">
            <span>
                <i class="fas fa-reply"></i> &nbsp; Regresar
            </span>
        </a>
    </div>

    <form method="post" action="<?php echo e(route('fechasEvaluacion')); ?>" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        
        <div class="row" <?php if($usuarioactual->tipo != 'coordinador'): ?> style="display:none;" <?php endif; ?>>
            <?php
                if ($fecha_evaluacion == null) {
                    $inicio = '';
                    $fin = '';
                } else {
                $inicio = date('d-m-Y', strtotime($fecha_evaluacion->fecha_inicio));
                $fin = date('d-m-Y', strtotime($fecha_evaluacion->fecha_fin));
                }
                
            ?>
            <strong>Duraci&oacute;n de la Evaluaci&oacute;n: </strong> <br>
            <div class="form-group col-md-2">
                <label class="form-control-label" for="fecha-inicio"><?php echo e(__('Fecha de Inicio')); ?></label>
                <input type="text" class="form-control" name="inicio" id="fecha-inicio" placeholder="dd-mm-aaaa" value="<?php echo e(old('inicio', $inicio)); ?>">
            </div>
            <div class="form-group col-md-2">
                <label class="form-control-label" for="fecha-fin"><?php echo e(__('Fecha Final')); ?></label>
                <input type="text" class="form-control" name="fin" id="fecha-fin" placeholder="dd-mm-aaaa" value="<?php echo e(old('fin',$fin)); ?>">
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Guardar')); ?></button>
            </div>
        </div>
    </form>


    <form role="form" method="post" action="<?php echo e(route('guardarEvaluacion')); ?>" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="pl-lg-4" id="preguntas">
            <?php if($usuarioactual->tipo == 'coordinador'): ?>
                <div class="row">
                    <div class="col-md text-right">
                        <button type="button" id="agregar" class="btn btn-primary btn-sm mt-4" data-toggle="modal" data-target="#modal-form2"><?php echo e(__('Agregar Pregunta')); ?></button>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($usuarioactual->tipo == 'alumno'): ?>
                <?php
                    $estudiante = App\User::where('users.id',$usuarioactual->id)
                            ->leftjoin('alumnos','alumnos.curp_alumno','=','users.curp_user')
                            ->get();
                    $docente_a_evaluar = App\Inscripcion::where('alumno_inscrito.num_control',$estudiante[0]->num_control)
                                                        ->orderBy('alumno_inscrito.updated_at','DESC')
                                                        ->leftjoin('grupos','grupos.id_grupo','=','alumno_inscrito.id_grupo')
                                                        ->leftjoin('docentes','docentes.id_docente','=','grupos.docente')
                                                        ->leftjoin('personas','personas.curp','=','docentes.curp_docente')
                                                        ->select('grupos.id_grupo','docentes.id_docente','personas.nombres','personas.ap_paterno','personas.ap_materno')
                                                        ->first();
                ?>
                
                <input type="hidden" name="docente" value="<?php echo e($docente_a_evaluar->id_docente); ?>">
                <input type="hidden" name="periodo" value="<?php echo e($periodo->id_periodo); ?>">
                <input type="hidden" name="grupo" value="<?php echo e($docente_a_evaluar->id_grupo); ?>">
                <div class="row">
                    Evaluaci&oacute;n docente a: &nbsp; <h5 class=" mb-1"><?php echo e($docente_a_evaluar->nombres); ?> <?php echo e($docente_a_evaluar->ap_paterno); ?> <?php if($docente_a_evaluar->ap_materno): ?> <?php echo e($docente_a_evaluar->ap_materno); ?> <?php endif; ?>
                </div>
                </h5>
            <?php endif; ?>

            <?php $i=0 ?>

            <?php $__currentLoopData = $tipoPregunta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <hr class="my-4" />
                <h6 class="heading-small text-muted mb-4"><?php echo e($tipo->clasificacion); ?></h6>
                
                <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    <?php if($pregunta->id_clasificacion == $tipo->id_clasificacion): ?>
                    <?php $i++ ?>
                        <div class="row" id="<?php echo e($pregunta->id_pregunta); ?>">
                            <?php if($usuarioactual->tipo == 'coordinador'): ?>
                                <a href="" data-idpreg="<?php echo e($pregunta->id_pregunta); ?>" data-preg="<?php echo e($pregunta->pregunta); ?>" data-toggle="modal" data-target="#modal-edit"><i class="fas fa-edit"></i></a>
                               <?php

                                    $estatus_evaluacion = App\Fechas::where('proceso','evaluacion')->first();
                               ?>
                                <?php if($estatus_evaluacion ==null || Carbon\Carbon::now() < $estatus_evaluacion->fecha_inicio || Carbon\Carbon::now() > $estatus_evaluacion->fecha_fin): ?>
                                    <a href="" id="" data-preguntaid="<?php echo e($pregunta->id_pregunta); ?>" data-toggle="modal" data-target="#modal-delete"><i class="fas fa-eraser"></i></a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <input type="hidden" name="preg-res<?php echo e($i); ?>[]" value="<?php echo e($pregunta->id_pregunta); ?>">
                            <div class="form-group col-md">
                                <label class="form-control-label" for="input-pregunta"><?php echo e($i.'.'); ?><?php echo e($pregunta->pregunta); ?></label>
                                <select id="input-pregunta" class="form-control col-md-4" name="preg-res<?php echo e($i); ?>[1]" required ><!-- name="preg-res[]"-->
                                    <option selected value="">Elija una opci&oacute;n</option>
                                    
                                    <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($respuesta->id_respuesta); ?>"><?php echo e($respuesta->respuesta); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($usuarioactual->tipo != 'coordinador'): ?>
                <div class="text-center">
                    <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Enviar Respuestas')); ?></button>
                </div>
            <?php endif; ?>
    </form>
<br><br>
<?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="col-md-6">

    <div class="modal fade" id="modal-form2" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="card bg-lighter shadow border-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <div class="text-center text-muted mb-4">
                                <strong><?php echo e(__('Nueva Pregunta')); ?></strong>
                            </div>

                            <form role="form" method="post" action="<?php echo e(route('agregarPregunta')); ?>" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <input class="form-control" name="pregunta" placeholder="Pregunta" type="text" value="<?php echo e(old('pregunta')); ?>">
                                    </div>
                                </div>
                                <label class="form-control-label" for="input-tipo"><?php echo e(__('Clasificación de la Pregunta')); ?></label>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <select id="input-tipo" class="form-control" name="tipo">
                                            <option selected value="">Clasificaci&oacute;n</option>
                                            <?php $__currentLoopData = $tipoPregunta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tipo->id_clasificacion); ?>"><?php echo e($tipo->clasificacion); ?></option>    
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select>
                                    </div>
                                </div>
                                <label class="form-control-label" for="input-vigencia"><?php echo e(__('Año de Vigencia')); ?></label>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <select id="input-vigencia" class="form-control" name="vigencia">
                                            <?php $anio = date('Y') ?>
                                            <option selected value="">Vigencia</option> 
                                            
                                            <?php for($i = 0; $i < 6; $i++): ?>
                                                <option value="<?php echo e($anio+$i); ?>"><?php echo e($anio+$i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Guardar')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="col-md-6">
    <div class="modal fade" id="modal-delete" tabindex="-1" role="dialog" aria-labelledby="modal-notification" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-" role="document">
            <div class="modal-content bg-gradient-white">
                
                <div class="modal-header">
                    <h6 class="modal-title" id="modal-title-notification">¡Espera!</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    
                </div>
                <form action="<?php echo e(route('eliminarPregunta','test')); ?>" method="POST" class="delete" id="deleteForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <div class="modal-body">
                    
                    <div class="py-3 text-center">
                            <i class="fas fa-times fa-3x" style="color:#CD5C5C;"></i>
                        <h4 class="heading mt-4">¡Da tu confirmaci&oacute;n para Eliminar!</h4>
                        <p>¿Realmente deseas eliminar la pregunta?</p>
                        <input type="hidden" name="idpregunta" id="idpregunta" value="">
                    </div>
                    
                </div>
                
                <div class="modal-footer">
                    <button type="submit" class="btn btn-outline-danger">S&iacute;, Eliminar</button>
                    <button type="button" class="btn btn-link text-gray ml-auto" data-dismiss="modal">No, Cambi&eacute; de opinion</button> 
                </div>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="col-md-6">
    <div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered " role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="card bg-lighter shadow border-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <div class="text-center text-muted mb-4">
                                <strong><?php echo e(__('Editar Pregunta')); ?></strong>
                            </div>

                            <form role="form" method="post" action="<?php echo e(route('guardarPregunta','test')); ?>" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <input class="form-control" name="pregunta" id="preguntaEdit" placeholder="Pregunta" type="text" value="<?php echo e(old('pregunta')); ?>">
                                    </div>
                                </div>
                                <label class="form-control-label" for="input-tipo"><?php echo e(__('Clasificación de la Pregunta')); ?></label>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <select id="input-tipo" class="form-control" name="tipo">
                                            <option selected value="">Clasificaci&oacute;n</option>
                                            <?php $__currentLoopData = $tipoPregunta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tipo->id_clasificacion); ?>"><?php echo e($tipo->clasificacion); ?></option>    
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                    </div>
                                </div>
                                
                                <label class="form-control-label" for="input-vigencia"><?php echo e(__('Año de Vigencia')); ?></label>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <select id="input-vigencia" class="form-control" name="vigencia">
                                            <?php $anio = date('Y') ?>
                                            <option selected value="">Vigencia</option> 
                                            
                                            <?php for($i = 0; $i < 6; $i++): ?>
                                                <option value="<?php echo e($anio+$i); ?>"><?php echo e($anio+$i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                <input type="hidden" id="idpreg" name="idpreg" value="">
                                <div class="text-center">
                                    <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Actualizar')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
    <script>
        
        $('#modal-delete').on('show.bs.modal', function(event){
            var button = $(event.relatedTarget) //
            // console.log(button)
            var pregunta_id = button.attr('data-preguntaid')
            // console.log(pregunta_id)
            var modal = $(this)
            // console.log(modal.find('.modal-body #nivel_id').val(alumn_id));
            modal.find('.modal-body #idpregunta').val(pregunta_id);
        } );



// 
    $('#modal-edit').on('show.bs.modal', function(event) {
        // console.log('open');
        var button = $(event.relatedTarget)
        var idpregunta = button.attr('data-idpreg')
        // var idpregunta = button.data('idpreg')
        var pregunt = button.attr('data-preg')
        console.log(idpregunta);
        var modal = $(this)
        modal.find('.modal-body #preguntaEdit').val(pregunt);
        modal.find('.modal-body #idpreg').val(idpregunta);
    });


        

</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/evaluacionDocente/evaluacion.blade.php ENDPATH**/ ?>