<?php $__env->startSection('sidebar'); ?>
<?php
$usuarioactual = \Auth::user();
?>
<?php if($usuarioactual->tipo == 'coordinador'): ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('layouts.navbars.sidebarEstudiantes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid m--t">
    <div class="col-md mt-4">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>No pudimos agregar los datos, <br> por favor, verifica la información</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <?php else: ?>
        <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md">
            <div class="text-right">

                <a href="<?php echo e(back()); ?>" class="btn btn-outline-primary mt-2 mb-4">
                    <span>
                        <i class="fas fa-reply"></i> &nbsp; Regresar
                    </span>
                </a>
            </div>
        </div>
    </div>
<form action="<?php echo e(route('inscribirEnGrupo')); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('post'); ?>
    <!-- header de la tabla-->
    <div class="row">
        <div class="col-xl">
            <div class="col-xl">
                <div class="card shadow ">
                    <div class="card-header border-3">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0"><?php echo e(__('Grupos Disponibles Periodo ')); ?><?php echo e($grupos[0]->descripcion); ?> <?php echo e($grupos[0]->anio); ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table align-items-center table-flush th">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">Grupo</th>
                                    <th scope="col">Nivel</th>
                                    <th scope="col">Idioma</th>
                                    <th scope="col">Aula</th>
                                    <th scope="col">Hora</th>
                                    <th scope="col">Docente</th>
                                    <th scope="col">Inscribirme</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $alumnos_en_el_grupo = App\Inscripcion::where('alumno_inscrito.id_grupo',$grupo->id_grupo)->count();
                                ?> 
                                <?php if($alumnos_en_el_grupo < $grupo->cupo): ?>
                                    <tr>
                                        <th scope="row">
                                            <span> <?php echo e($grupo->grupo); ?></span>
                                        </th>
                                        <th>
                                            <?php echo e($grupo->nivel); ?><?php echo e($grupo->modulo); ?>

                                        </th>
                                        <th>
                                            <?php echo e($grupo->idioma); ?>

                                        </th>
                                        <th>
                                            <?php echo e($grupo->edificio); ?><?php echo e($grupo->num_aula); ?>

                                        </th>
                                        <th>
                                            <?php echo e($grupo->hora); ?>

                                        </th>
                                        <th>
                                            <?php echo e($grupo->nombres); ?> <?php echo e($grupo->ap_paterno); ?> <?php echo e($grupo->ap_materno); ?>

                                        </th>
                                        <td>
                                            <div class="custom-control custom-radio mb-0">
                                                <input name="grupo" class="custom-control-input" id="grupo<?php echo e($grupo->id_grupo); ?>" type="radio" value="<?php echo e($grupo->id_grupo); ?>">
                                                <label class="custom-control-label" for="grupo<?php echo e($grupo->id_grupo); ?>">G</label>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <div class="text-center">
        <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Inscribirme')); ?></button>
    </div>
</form>
    <br><br>
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/inscripciones/inscripcionAlumno.blade.php ENDPATH**/ ?>