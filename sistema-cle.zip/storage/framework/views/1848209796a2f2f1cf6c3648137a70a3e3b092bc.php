<?php $__env->startSection('sidebar'); ?>
<?php
$usuarioactual = \Auth::user();
?>
<?php if($usuarioactual->tipo == 'coordinador'): ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if($usuarioactual->tipo == 'alumno'): ?>
<?php echo $__env->make('layouts.navbars.sidebarEstudiantes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if($usuarioactual->tipo == 'docente'): ?>
<?php echo $__env->make('layouts.navbars.sidebarDocentes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if($usuarioactual->tipo == 'escolares'): ?>
<?php echo $__env->make('layouts.navbars.sidebarEscolares', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
.sinborde {
   border: 0;
 }
.ancho{
    width: 100%;
    height: 100%;
}

</style>

<div class="container-fluid m--t">
    <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center" >
        <div class="col-lg col-md">
            <h4 class="text-dark">Grupo <?php echo e($infoGrupo[0]->grupo); ?> <?php echo e($infoGrupo[0]->nivel); ?><?php echo e($infoGrupo[0]->modulo); ?></h4>
            <h6 class="text-dark"><?php echo e($infoGrupo[0]->edificio); ?><?php echo e($infoGrupo[0]->aula); ?> <?php echo e($infoGrupo[0]->hora); ?></h6>
        </div>
        
    </div>
    <div class="msj">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="text-right mb-2">
        <a href=" <?php echo e(route('boletas')); ?> " class="btn btn-outline-primary btn-sm mt-3">
            <span>
                <i class="fas fa-reply"></i> &nbsp; Regresar
            </span>
        </a>
    </div> 
    <div class="mb-3" <?php if($usuarioactual->tipo=='alumno' || $usuarioactual->tipo=='escolares'): ?> style="display:none" <?php else: ?> style="display:block" <?php endif; ?>>
        <a href=" <?php echo e(route('actaCalificaciones',$infoGrupo[0]->id_grupo)); ?> " class="btn btn-outline-default btn-sm mt-3">
            <span>
                <i class="far fa-file-alt"></i> &nbsp; Acta de Calificaciones
            </span>
        </a>
    </div> 
    
    <form method="post" action="<?php echo e(route('guardarCalificaciones')); ?>" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <input type="hidden" name="grupo" value="<?php echo e($infoGrupo[0]->id_grupo); ?>">
        
        <div class="row">    
            <div class="col-xl">
                <div class="col-xl">
                    <div class="card shadow ">
                        <div class="table-responsive">
                            <table id="tabledata" class="table align-items-center table-flush th">
                                <thead class="thead-light">
                                    <tr class="card-header">
                                        <th class="text">N&uacute;mero <br>de Control </th>
                                        <th class="text">Estudiante</th>
                                        <th class="text">Parcial 1</th>
                                        <th class="text">Parcial 2</th>
                                        <th class="text">Parcial 3</th>
                                        <th class="text">Faltas</th>
                                        <th class="text">Final</th>
                                        <?php if($usuarioactual->tipo != 'docente'): ?>
                                        <th class="text">Boleta</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody> <?php $i=0 ?>
                                    <?php $__currentLoopData = $alumnos_inscritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <tr class="hide">
                                            <td id="num" class="num_control pt-3-half" contenteditable="false"><?php echo e($alumno->num_control); ?></td>
                                            <input type="hidden" name="calif<?php echo e($i); ?>[]" value="<?php echo e($alumno->num_control); ?>">
                                            <th class="pt-3-half"><?php echo e($alumno->ap_paterno); ?> <?php echo e($alumno->ap_materno); ?> <?php echo e($alumno->nombres); ?> </th>
                                            <td class="calif1 pt-3-half ">
                                                <input type="number" max="100" name="calif<?php echo e($i); ?>[]" class="sinborde ancho"  <?php if($alumno->calif1==null): ?> value="0" <?php else: ?> value="<?php echo e($alumno->calif1); ?>"<?php endif; ?>
                                                <?php if($usuarioactual->tipo=='docente' || $usuarioactual->tipo=='coordinador'): ?> <?php if($alumno->calif1!=null && $alumno->calif1>0): ?> readonly <?php endif; ?> <?php endif; ?> 
                                                <?php if($usuarioactual->tipo=='alumno'): ?> readonly <?php endif; ?>>
                                            </td>
                                            <td class="calif2 pt-3-half">
                                                <input type="number" max="100" name="calif<?php echo e($i); ?>[]" class="sinborde ancho" <?php if($alumno->calif2==null): ?> value="0" <?php else: ?> value="<?php echo e($alumno->calif2); ?>"<?php endif; ?>
                                                <?php if($usuarioactual->tipo=='docente' || $usuarioactual->tipo=='coordinador'): ?> <?php if($alumno->calif2!=null && $alumno->calif2>0): ?> readonly <?php endif; ?> <?php endif; ?> 
                                                <?php if($usuarioactual->tipo=='alumno'): ?> readonly <?php endif; ?>>
                                            </td>
                                            <td class="calif3 pt-3-half">
                                                <input type="number" max="100" name="calif<?php echo e($i); ?>[]" class="sinborde ancho" <?php if($alumno->calif3==null): ?> value="0" <?php else: ?> value="<?php echo e($alumno->calif3); ?>"<?php endif; ?>
                                                <?php if($usuarioactual->tipo=='docente' || $usuarioactual->tipo=='coordinador'): ?> <?php if($alumno->calif3!=null && $alumno->calif3>0): ?> readonly <?php endif; ?> <?php endif; ?> 
                                                <?php if($usuarioactual->tipo=='alumno'): ?> readonly <?php endif; ?>>
                                            </td>
                                            <td class="faltas pt-3-half">
                                                <input type="number" max="100" name="calif<?php echo e($i); ?>[]" class="sinborde ancho" <?php if($alumno->faltas==null): ?> value="0" <?php else: ?> value="<?php echo e($alumno->faltas); ?>"<?php endif; ?>
                                                <?php if($usuarioactual->tipo=='docente' || $usuarioactual->tipo=='coordinador'): ?> <?php if($alumno->faltas!=null): ?> readonly <?php endif; ?> <?php endif; ?> 
                                                <?php if($usuarioactual->tipo=='alumno'): ?> readonly <?php endif; ?>>
                                            </td>
                                            <th class="pt-3-half"><?php echo e($alumno->calif_f); ?></th>
                                            <?php if($usuarioactual->tipo != 'docente'): ?>
                                            <td>
                                                <a href="<?php echo e(route('boletaIndividual',[$infoGrupo[0]->id_grupo,$alumno->num_control])); ?>"><i class="fas fa-file-download"></i></a>
                                            </td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php $i++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center" <?php if($usuarioactual->tipo=='alumno'): ?> style="display:none" <?php else: ?> style="display:block" <?php endif; ?>>
            <button type="submit" id="guardar" class="btn btn-primary mt-4">Registrar Calificaciones</button>
        </div>
    </form>
    <br><br>
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

    <?php $__env->startSection('script'); ?>
        <script>
            var json="";
            $(document).ready(function(){
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $('#formtable').on('submit',function(e){
                    e.preventDefault();
                    // var todo= [];


                    // todo
                    // $('#tabledata tbody tr').each(function(index){
                    //     var uno = [];
                    //     $(this).find('td').each(function(index) {
                    //         uno [index]= $(this).html() + ",";
                    //     });
                    //      todo[index]=uno;
                    // });
                    //  console.log(todo);

                    // funtion guardar(tablaid){
                    //     var t = $('#'+tablaid+'')
                    // }


                    $("table tbody tr").each(function () {
                        json ="";
                        $(this).find("td").each(function () {
                            $this=$(this);
                            json+=',"'+$this.attr("id")+'":"'+$this.html()+'"'
                        });
                        obj=JSON.parse('{'+json.substr(1)+'}');
                        console.log(obj);
                    });
                    // var arr = obj.pushItem
                    

                    // console.log(json);
                    $.ajax({
                        type:'POST',
                        url:"<?php echo e(route('guardarCalificaciones')); ?>",
                        data:json,
                        // dataType:'json',
                        success:function(data){
                            // var datos = data.responseText;
                            console.log(data);
                            // $('.msj').append('<div class="alert alert-danger alert-block">'+
                            //                 '<button type="button" class="close" data-dismiss="alert">×</button>'+
                            //                 '<strong>Exito</strong>'+
                            //                 '</div>')
                        },
                        
                    });
                });
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/boletas/calificaciones.blade.php ENDPATH**/ ?>