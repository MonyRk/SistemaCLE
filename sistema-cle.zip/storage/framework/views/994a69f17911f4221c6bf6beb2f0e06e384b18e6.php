<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebarEscolares', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="text-right">
        <a href=" <?php echo e(back()); ?> " class="btn btn-outline-primary btn-sm mt-4">
            <span>
                <i class="fas fa-reply"></i> &nbsp; Regresar
            </span>
        </a>
    </div>
    <div class="container-fluid mt-4">
        <div>
            <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    <strong>No pudimos agregar los datos, <br> por favor, verifica la información</strong>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>  
                </div>    
             
            <?php else: ?> 
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                     <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>                           
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="col-xl-12 order-xl-1">
                <div class="card bg-lighter shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Editar Usuario')); ?></h3>
                            </div>
                            
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('actualizarUsuario')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>

                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Informacion del usuario')); ?></h6>
                            <div class="pl-lg-4">
                                <div class="form-row">
                                    <div class="col-md">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Nombre(s)')); ?></label>
                                        <input type="text" name="name" id="input-name" class="form-control form-control-alternative" placeholder="" value="<?php echo e(old('name',$user->name)); ?>"  autofocus>
                                    </div>
                                    <div class="col-md">
                                        <label class="form-control-label" for="input-apPaterno"><?php echo e(__('Apellido Paterno')); ?></label>
                                        <input type="text" name="apPaterno" id="input-apPaterno" class="form-control form-control-alternative" placeholder="" value="<?php echo e(old('apPaterno',$user->ap_paterno)); ?>"  >
                                    </div>
                                    <div class="col-md">
                                        <label class="form-control-label" for="input-apMaterno"><?php echo e(__('Apellido Materno')); ?></label>
                                        <input type="text" name="apMaterno" id="input-apMaterno" class="form-control form-control-alternative" placeholder="" value="<?php echo e(old('apMaterno',$user->ap_materno)); ?>" >
                                    </div>
                                </div><br>
                                <div class="form-row">
                                    <div class="form-group col-md">
                                        <label class="form-control-label" for="input-curp"><?php echo e(__('CURP')); ?></label>
                                        <input readonly type="text" class="form-control form-control-alternative" name="curp" id="input-curp" value="<?php echo e(old('curp',$user->curp)); ?>" onkeyup="this.value = this.value.toUpperCase();" >
                                    </div>
                                    <div class="form-group col-md">
                                        <label class="form-control-label" for="input-email"><?php echo e(__('Email')); ?></label>
                                        <input type="email" name="email" id="input-email" class="form-control form-control-alternative" placeholder="" value="<?php echo e(old('email',$user->email)); ?>" >
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-control-label" for="input-password"><?php echo e(__('Contraseña')); ?></label>
                                    <input type="password" name="password" id="input-password" class="form-control form-control-alternative" placeholder="" value="" >
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-password-confirmation"><?php echo e(__('Confirmar Contraseña')); ?></label>
                                    <input type="password" name="password_confirmation" id="input-password-confirmation" class="form-control form-control-alternative" placeholder="" value="" >
                                </div>
                                <div class="form-group col-md">
                                        <label class="form-control-label" for="input-estatus"><?php echo e(__('Estatus')); ?></label>
                                        <select id="input-estatus" class="form-control form-control-alternative" name="estatus">
                                            <option selected <?php if($user->deleted_at == null): ?> value="activo" <?php else: ?> value="inactivo" <?php endif; ?>><?php if($user->deleted_at == null): ?> <?php echo e('Activo'); ?> <?php else: ?> <?php echo e('Inactivo'); ?> <?php endif; ?></option>
                                                <option value="activo">Activo</option>  
                                                <option value="inactivo">Inactivo</option>                            
                                        </select>                  
                                    </div>
                                
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Guardar')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/users/edit.blade.php ENDPATH**/ ?>