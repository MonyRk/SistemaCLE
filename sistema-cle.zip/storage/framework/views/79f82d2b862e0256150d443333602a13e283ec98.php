<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="header pb-2 pt-5 pt-lg-8 d-flex align-items-center text-center" >
    <div class="col-lg col-md">
        <h4 class="text-dark"><?php echo $__env->yieldContent('titlecreate'); ?></h4>
    </div>
</div>
    
    <div class="container-fluid m--t">
            <div class="text-right">
                <a href=" <?php echo $__env->yieldContent('regresar'); ?> " class="btn btn-outline-primary btn-sm mt-4">
                    <span>
                        <i class="fas fa-reply"></i> &nbsp; Regresar
                    </span>
                </a>
            </div>
        <div class="card-body ">
            
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-block pt-2">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    <strong>No pudimos agregar los datos, <br> por favor, verifica la información</strong>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>  
                </div> 
            <?php else: ?> 
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                     <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>                           
            <?php endif; ?>

        <form method="post" action="<?php echo $__env->yieldContent('action'); ?>" autocomplete="off" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Personal')); ?></h6>
            <p class="text-muted">La informaci&oacute;n proporcionada en &eacute;sta p&aacute;gina web ser&aacute; utilizada para fines 
                acad&eacute;micos y s&oacute;lo por la Coordinaci&oacute;n de Lenguas Extranjeras.</p>
            <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                   
                </div>
            <?php endif; ?>

            <div class="pl-lg-4">
                <div class="row">
                    <div class="col-md">
                        <label class="form-control-label" for="input-name"><?php echo e(__('Nombre(s)')); ?></label>
                        <input type="text" name="name" id="input-name" class="form-control" placeholder="" value="<?php echo e(old('name')); ?>" >
                    </div>
                    <div class="col-md"> 
                        <label class="form-control-label" for="input-apPaterno"><?php echo e(__('Apellido Paterno')); ?></label>
                        <input type="text" name="apPaterno" id="input-apPaterno" class="form-control" placeholder="" value="<?php echo e(old('apPaterno')); ?>" >
                    </div>
                    <div class="col-md">
                        <label class="form-control-label" for="input-apMaterno"><?php echo e(__('Apellido Materno')); ?></label>
                        <input type="text" name="apMaterno" id="input-apMaterno" class="form-control" placeholder="" value="<?php echo e(old('apMaterno')); ?>">
                    </div>
                </div>
                
                <br>

                <div class="form-row">
                    <div class="form-group col-md-5">
                        <label class="form-control-label" for="input-curp"><?php echo e(__('CURP')); ?></label>
                        <input type="text" class="form-control" name="curp" id="input-curp" onkeyup="this.value = this.value.toUpperCase();" value="<?php echo e(old('curp')); ?>" data-toggle="tooltip" data-placement="bottom" title="Aseg&uacute;rate de escribir la CURP correctamente">
                    </div>
                    <div class="form-group col-md-2">
                        <label class="form-control-label" for="input-edad"><?php echo e(__('Edad')); ?></label>
                        <input type="text" class="form-control" name="edad" id="input-edad" value="<?php echo e(old('edad')); ?>">
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-sexo"><?php echo e(__('Sexo')); ?></label>
                        <div class="row">            
                            <div class="custom-control custom-radio">
                                <input type="radio" id="sexof" name="sexo" value="F" class="custom-control-input">
                                <label class="custom-control-label" for="sexof">&nbsp&nbsp&nbsp&nbsp&nbspFemenino</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" id="sexom" name="sexo" value="M" class="custom-control-input">
                                <label class="custom-control-label" for="sexom">&nbsp&nbsp&nbsp&nbsp&nbspMasculino</label>
                            </div>
                        </div>
                    </div>
                </div>
                <label class="form-control-label"><?php echo e(__('Dirección')); ?></label>
                <div class="row">
                    <div class="form-group col-md" id="direccion">
                        <label class="form-control-label" for="input-calle"><?php echo e(__('Calle')); ?></label>
                        <input type="text" name="calle" id="input-calle" class="form-control"  value="<?php echo e(old('calle')); ?>" >
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-numero"><?php echo e(__('Número')); ?></label>
                        <input type="text" name="numero" id="input-numero" class="form-control"  value="<?php echo e(old('numero')); ?>" >
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-colonia"><?php echo e(__('Colonia')); ?></label>
                        <input type="text" name="colonia" id="input-colonia" class="form-control"  value="<?php echo e(old('colonia')); ?>" >
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-municipio"><?php echo e(__('Municipio')); ?></label>
                        <select id="input-municipio" class="form-control" name="municipio">
                            <option selected value=""></option>
                                <?php $__currentLoopData = $nombres_municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mun->id); ?>"><?php echo e($mun->nombre_municipio); ?></option>                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                  
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-cp"><?php echo e(__('C. P.')); ?></label>
                        <input type="text" name="cp" id="input-cp" class="form-control" value="<?php echo e(old('cp')); ?>" >
                    </div>
                </div>
<br>
                <div class="form-row">
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-telefono"><?php echo e(__('Teléfono')); ?></label>
                        <input type="text" name="telefono" id="input-telefono" class="form-control" placeholder="" value="<?php echo e(old('telefono')); ?>">
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-email"><?php echo e(__('Email')); ?></label>
                        <input type="text" name="email" id="input-email" class="form-control form-control-alternative" placeholder="" value="<?php echo e(old('email')); ?>">
                    </div>
                </div>
                </div>
        
        <hr class="my-4" />

        <?php echo $__env->yieldContent('nombreTipodeInformacion'); ?>

        <div class="pl-lg-4">
            <?php echo $__env->yieldContent('informacionporTipo'); ?>
            
            <div class="text-center">
                <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Guardar')); ?></button>
            </div>
            </div>
        </form>
    </div>
</div>

    <br><br>
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/viewsBase/create.blade.php ENDPATH**/ ?>