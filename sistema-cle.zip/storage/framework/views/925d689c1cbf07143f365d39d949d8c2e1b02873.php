<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid m--t">
        <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center">
            <div class="col-lg col-md">
                <h4 class="text-dark"></h4>
            </div>
        </div>
        <div class="card-body">
            <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    
        <div class="text-right">
            <a href="<?php echo e(route('inicio')); ?>" class="btn btn-outline-primary btn-sm mt-2">
                <span>
                    <i class="fas fa-reply"></i> &nbsp; Regresar
                </span>
            </a>
        </div>
        <form action="<?php echo e(route('contratos')); ?>" method="GET">
            <div class="row">
                <div class="col-lg-4"></div>
                <div class="col-lg-4 text-center">
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-docente"><?php echo e(__('Docente')); ?></label>
                        <select id="input-docente" class="form-control" name="docente">
                            <option ></option>
                            <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($docente->id_docente); ?>"><?php echo e($docente->nombres); ?> <?php echo e($docente->ap_paterno); ?> <?php if($docente->ap_materno): ?> <?php echo e($docente->ap_materno); ?> <?php endif; ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select> 
                    </div>
                    <div class="col-lg-4"></div>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-3">
                    <label class="form-control-label" for="input-idioma"><?php echo e(__('Idioma a Impartir')); ?></label>
                    <input type="text" name="idioma" id="input-idioma" class="form-control" placeholder="" value="<?php echo e(old('idioma')); ?>">
                </div> 
                <div class="form-group col-md-3">
                    <label class="form-control-label" for="input-nivel"><?php echo e(__('Nivel a Impartir')); ?></label>
                    <input type="text" name="nivel" id="input-nivel" class="form-control" placeholder="" value="<?php echo e(old('nivel')); ?>">
                </div> 
                <div class="form-group col-md-3">
                    <label class="form-control-label" for="input-rfc"><?php echo e(__('RFC')); ?></label>
                    <input type="text" name="rfc" id="input-rfc" class="form-control" placeholder="" value="<?php echo e(old('rfc')); ?>">
                </div> 
                <div class="form-group col-md-3">
                    <label class="form-control-label" for="input-titulo"><?php echo e(__('Título')); ?></label>
                    <input type="text" name="titulo" id="input-titulo" class="form-control" placeholder="" value="<?php echo e(old('titulo')); ?>">
                </div>                          
            </div> 
            <div class="row">
                <div class="form-group col-md-3">
                    <label class="form-control-label" for="input-fecha_pago"><?php echo e(__('Fecha de Pago')); ?></label>
                    <input type="text" name="fecha_pago" id="input-fecha_pago" class="form-control" placeholder="01 de octubre de 2019" value="<?php echo e(old('fecha_pago')); ?>">
                </div>  
                <div class="form-group col-md-3">
                    <label class="form-control-label" for="input-importe"><?php echo e(__('Importe a Pagar')); ?></label>
                    <input type="text" name="importe" id="input-importe" class="form-control" placeholder="0,000" value="<?php echo e(old('importe')); ?>">
                </div> 
                <div class="form-group col-md-3">
                    <label class="form-control-label" for="input-inicio"><?php echo e(__('Fecha de Inicio')); ?></label>
                    <input type="text" name="inicio" id="input-inicio" class="form-control" placeholder="01 de octubre de 2019" value="<?php echo e(old('inicio')); ?>">
                </div>
                <div class="form-group col-md-3">
                        <label class="form-control-label" for="input-fin"><?php echo e(__('Fecha Final')); ?></label>
                        <input type="text" name="fin" id="input-fin" class="form-control" placeholder="01 de octubre de 2019" value="<?php echo e(old('fin')); ?>">
                    </div>                           
            </div>                
                    
            <div class="text-center">
                <button type="submit" class="btn btn-primary mt-4">Generar Adendum</button>
            </div>
                
                
        </form>
        <br><br><br><br>
        <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/reportes/acuerdosLaborales.blade.php ENDPATH**/ ?>