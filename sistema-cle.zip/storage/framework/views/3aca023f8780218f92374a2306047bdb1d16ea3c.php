    
    <div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="modal-default" aria-hidden="true">
  <div class="modal-dialog modal- modal-dialog-centered modal-" role="document">
      <div class="modal-content">
          
          <div class="modal-header">
              <h6 class="modal-title" id="modal-title-default"><?php echo $__env->yieldContent('titulo'); ?></h6>
              
          </div>
          
          <div class="modal-body">
              <?php echo $__env->yieldContent('contenido'); ?>
          </div>
          
          <div class="modal-footer">
              
              <button type="button" class="btn btn-link  ml-auto" data-dismiss="modal">Close</button> 
          </div>
          
      </div>
  </div>
</div><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/modals.blade.php ENDPATH**/ ?>