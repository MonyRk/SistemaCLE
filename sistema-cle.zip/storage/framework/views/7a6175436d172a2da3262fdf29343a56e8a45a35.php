<?php $__env->startSection('contenidoLiberacion'); ?>
<?php
    setlocale (LC_TIME, "es_ES");
?>
<p align="justify">
        Por este conducto, los que suscriben, integrantes del Jurado para el proceso 
        de convalidaci&oacute;n de acreditaci&oacute;n de una lengua extranjera, hacen constar que el (la) 
        estudiante <strong> C. <?php echo e($datosEstudiante[0]->ap_paterno); ?> <?php if($datosEstudiante[0]->ap_materno!=null): ?> <?php echo e($datosEstudiante[0]->ap_materno); ?> <?php endif; ?> <?php echo e($datosEstudiante[0]->nombres); ?></strong>
        con n&uacute;mero de control <strong><?php echo e($datosEstudiante[0]->num_control); ?></strong> de la carrera
        <?php echo e($datosEstudiante[0]->carrera); ?> con clave del plan de estudios <?php echo e($plan); ?> 
    present&oacute; boleta de Examen <?php echo e($certificacion); ?> de <?php echo e($puntos); ?> puntos con lo cual acredita haber cubierto 
    el nivel <?php echo e($nivel); ?>.
    
</p>
<p align="justify"> Por lo anterior se considera que el (la) estudiante <strong>S&Iacute; CUMPLE</strong>, 
    con el requisito de lengua extranjera para efectos de titulaci&oacute;n en una licenciatura del 
    Sistema Nacional de Educaci&oacute;n Superior Tecnol&oacute;gica.</p>
   <p align="justify"> Se extiende la presente en la ciudad de Oaxaca de Ju&aacute;rez, Oax a los 
        <?php echo e(NumerosEnLetras::convertir(strftime("%d"))); ?> d&iacute;as del mes de <?php echo e(strftime("%B")); ?> 
        del año <?php echo e(NumerosEnLetras::convertir(strftime("%Y"))); ?>, a petici&oacute;n del (la) interesado (a).
<?php $__env->stopSection(); ?>
<?php echo $__env->make('viewsBase.liberacionespdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/pdf/liberacionCertificacionPdf.blade.php ENDPATH**/ ?>