<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
        <div class="container-fluid">
            <!-- Toggler -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Brand -->
            <a class="navbar-brand pt-0" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('argon')); ?>/img/brand/logog.png" class="navbar-brand-img" alt="...">
            </a>
            <!-- User -->
            <ul class="nav align-items-center d-md-none">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="media align-items-center">
                                <span class="mb-0 text-sm  font-weight-bold text-black"><?php echo e(auth()->user()->name); ?></span>
                            
                        </div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                        
                        
                        
                        
                        <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                            <i class="ni ni-user-run"></i>
                            <span><?php echo e(__('Cerrar sesión')); ?></span>
                        </a>
                    </div>
                </li>
            </ul>
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <!-- Collapse header -->
                <div class="navbar-collapse-header d-md-none">
                    <div class="row">
                        <div class="col-6 collapse-brand">
                            <a href="<?php echo e(route('home')); ?>">
                                <img src="<?php echo e(asset('argon')); ?>/img/brand/logog.png">
                            </a>
                        </div>
                        <div class="col-6 collapse-close">
                            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                    </div>
                </div>
                <!-- Form -->
                
                <?php 
                    $usuarioactual = \Auth::user();
                    $alumno = App\User::where('users.id',$usuarioactual->id)
                            ->leftjoin('personas','personas.curp','=','users.curp_user')
                            ->leftjoin('alumnos','personas.curp','=','alumnos.curp_alumno')
                            ->get();
                    $periodo_actual = App\Periodo::where('actual',true)->first();
                ?>
                <!-- Navigation -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">
                            <i class="ni ni-tv-2 text-primary"></i> <?php echo e(__('Principal')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('editarEstudiante',$alumno[0]->num_control)); ?>" >
                            <i class="fas fa-users text-danger" style= "color: danger"></i><?php echo e(__('Información')); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('indexpagos')); ?>">
                            <i class="fas fa-receipt text-dark"></i><?php echo e(__('Pagos')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('inscribirAlumno',$alumno[0]->num_control)); ?>" >
                            <i class="fas fa-user-edit text-green"></i> <?php echo e(__('Inscripciones')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('avance').'?numControl='.$alumno[0]->num_control); ?>">
                            <i class="fas fa-layer-group text-purple"></i> <?php echo e(__('Avance')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('boletas')); ?>">
                            <i class="fas fa-check text-info"></i> <?php echo e(__('Calificaciones')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('evaluacion').'?periodo='.$periodo_actual->id_periodo); ?>">
                            <i class="fas fa-question text-gray"></i> <?php echo e(__('Evaluación Docente')); ?>

                        </a>
                    </li>                
            </div>
        </div>
    </nav><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/layouts/navbars/sidebarEstudiantes.blade.php ENDPATH**/ ?>