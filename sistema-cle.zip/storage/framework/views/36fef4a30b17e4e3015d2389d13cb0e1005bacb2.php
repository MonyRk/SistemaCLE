<div class="col-md-4">
    <button type="button" class="btn btn-block btn-white" data-toggle="modal" data-target="#modal-form"><i class="fas fa-plus-circle"></i></button>
        <div class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
            <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body p-0">
                        <div class="card bg-lighter shadow border-0">
                            <div class="card-body px-lg-5 py-lg-5">
                                <?php echo $__env->yieldContent('inputs'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/viewsBase/modal.blade.php ENDPATH**/ ?>