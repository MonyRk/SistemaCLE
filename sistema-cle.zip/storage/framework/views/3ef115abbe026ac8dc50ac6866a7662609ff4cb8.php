<?php $__env->startSection('regresar'); ?>
<?php echo e(route('verEstudiantes')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('informacion'); ?>
<hr class="my-4"/>
    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Escolar')); ?></h6>
    <div>
        <div class="row">
            <div class="col-xl col-lg-6">
                    <div class="card card-stats mb-4 mb-xl">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <span class="card-title"><?php echo e(__('Número de Control: ')); ?></span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="">
                                    <p class="card-text font-weight-bold"><?php echo e($datos[0]->num_control); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl col-lg-6">
                    <div class="card card-stats mb-4 mb-xl">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <span class="card-title"><?php echo e(__('Carrera: ')); ?></span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="">
                                    <p class="card-text font-weight-bold"><?php echo e($datos[0]->carrera); ?><p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl col-lg-6">
                    <div class="card card-stats mb-4 mb-xl">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <span class="card-title"><?php echo e(__('Semestre: ')); ?></span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="">
                                    <p class="card-text font-weight-bold"><?php echo e($datos[0]->semestre); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl col-lg-6">
                    <div class="card card-stats mb-4 mb-xl">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <span class="card-title"><?php echo e(__('Estatus: ')); ?></span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="">
                                    <p class="card-text font-weight-bold"><?php echo e($datos[0]->estatus); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('viewsBase.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/alumnos/showEstudiante.blade.php ENDPATH**/ ?>