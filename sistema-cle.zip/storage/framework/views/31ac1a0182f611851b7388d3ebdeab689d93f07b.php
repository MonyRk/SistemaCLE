<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div class="header pb-5 pt-5 pt-lg-8 d-flex align-items-center" >
</div>
    
    <div class="container-fluid m--t">
    <div class="card-body ">
        <form method="post" action="<?php echo e(url("alumnos/{$alumno[0]->num_control}")); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Personal')); ?></h6>
            
            <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                   
                </div>
            <?php endif; ?>

            <div class="pl-lg-4">
                <div class="row">
                    <div class="col-md">
                        <label class="form-control-label" for="input-name"><?php echo e(__('Nombre(s)')); ?></label>
                        <input type="text" name="name" id="input-name" class="form-control" placeholder="" value="<?php echo e(old('name', $alumno[0]->nombres)); ?>" required autofocus>
                    </div>
                    <div class="col-md">
                        <label class="form-control-label" for="input-apPaterno"><?php echo e(__('Apellido Paterno')); ?></label>
                        <input type="text" name="apPaterno" id="input-apPaterno" class="form-control" placeholder="" value="<?php echo e(old('apPaterno', $alumno[0]->ap_paterno)); ?>" required autofocus>
                    </div>
                    <div class="col-md">
                        <label class="form-control-label" for="input-apMaterno"><?php echo e(__('Apellido Materno')); ?></label>
                        <input type="text" name="apMaterno" id="input-apMaterno" class="form-control" placeholder="" value="<?php echo e(old('apMaterno', $alumno[0]->ap_materno)); ?>" required autofocus>
                    </div>
                </div>
                
                <br>

                <div class="form-row">
                    <div class="form-group col-md-5">
                        <label class="form-control-label" for="input-curp"><?php echo e(__('CURP')); ?></label>
                        <input type="text" class="form-control" name="curp" id="input-curp" value="<?php echo e(old('curp', $alumno[0]->curp)); ?>">
                    </div>
                    <div class="form-group col-md-2">
                        <label class="form-control-label" for="input-edad"><?php echo e(__('Edad')); ?></label>
                        <input type="text" class="form-control" name="edad" id="input-edad" value="<?php echo e(old('edad', $alumno[0]->edad)); ?>">
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-sexo" ><?php echo e(__('Sexo')); ?></label>
                        <div class="row">            
                            <div class="custom-control custom-radio">
                                <input type="radio" id="sexof" name="sexo" value="<?php echo e(old('sexo', $alumno[0]->sexo)); ?>" class="custom-control-input">
                                <label class="custom-control-label" for="sexof">&nbsp&nbsp&nbsp&nbsp&nbspFemenino</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" id="sexom" name="sexo" value="<?php echo e(old('sexo', $alumno[0]->sexo)); ?>" class="custom-control-input">
                                <label class="custom-control-label" for="sexom">&nbsp&nbsp&nbsp&nbsp&nbspMasculino</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-telefono"><?php echo e(__('Teléfono')); ?></label>
                        <input type="text" name="telefono" id="input-telefono" class="form-control" placeholder="" value="<?php echo e(old('telefono', $alumno[0]->telefono)); ?>" required autofocus>
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-email"><?php echo e(__('Email')); ?></label>
                        <input type="email" name="email" id="input-email" class="form-control form-control-alternative" placeholder="" value="<?php echo e(old('email', $alumno[0]->email)); ?>" required>
                    </div>
                </div>
        
        <hr class="my-4" />

            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Escolar')); ?></h6>
            <div class="row">
                <div class="form-group col-md-4">
                    <label class="form-control-label" for="input-numControl"><?php echo e(__('Número de Control')); ?></label>
                    <input type="text" name="numControl" id="input-numControl" class="form-control" placeholder="" value="<?php echo e(old('numControl', $alumno[0]->num_control)); ?>">
                </div>
                <div class="form-group col-md-6">
                    <label class="form-control-label" for="input-carrera"><?php echo e(__('Carrera')); ?></label>
                    <select id="input-carrera" class="form-control" name="carrera" value="<?php echo e(old('carrera', $alumno[0]->carrera)); ?>">
                    <option selected value="<?php echo e(old('carrera', $alumno[0]->carrera)); ?>"><?php echo e(old('carrera', $alumno[0]->carrera)); ?></option>
                    <option value="Ingeniería Eléctrica"><?php echo e(__('Ing. Eléctrica')); ?></option>
                    <option value="Ingeniería Electrónica"><?php echo e(__('Ing. Electrónica')); ?></option>
                    <option value="Ingeniería Civil"><?php echo e(__('Ing. Civil')); ?></option>
                    <option value="Ingeniería Mecánica"><?php echo e(__('Ing. Mecánica')); ?></option>
                    <option value="Ingeniería Industrial"><?php echo e(__('Ing. Industrial')); ?></option>
                    <option value="Ingeniería Química"><?php echo e(__('Ing. Química')); ?></option>
                    <option value="Ingeniería en Gestión Empresarial"><?php echo e(__('Ing. Gestión Empresarial')); ?></option>
                    <option value="Ingeniería en Sist. Computacionales"><?php echo e(__('Ing. Sistemas Computacionales')); ?></option>
                    <option value="Licenciatura en Administración"><?php echo e(__('Lic. Administración')); ?></option>
                    </select>
                </div>
                <div class="form-group col-md-2">
                        <label class="form-control-label" for="input-semestre"><?php echo e(__('Semestre')); ?></label>
                        <select  id="input-semestre" class="form-control" name="semestre">
                        <option selected value="<?php echo e(old('semestre', $alumno[0]->semestre)); ?>"><?php echo e(old('semestre', $alumno[0]->semestre)); ?></option>
                            <?php for($i = 1; $i <= 12; $i++): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e(($i)); ?></option>
                            <?php endfor; ?> 
                        </select>
                </div>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Guardar')); ?></button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/alumnos/edit.blade.php ENDPATH**/ ?>