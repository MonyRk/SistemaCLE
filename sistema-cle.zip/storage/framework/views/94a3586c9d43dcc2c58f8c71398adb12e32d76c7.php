<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center" >
    <div class="col-lg col-md">
        <h4 class="text-dark">Grupo <?php echo e($grupo[0]->grupo); ?> <?php echo e($grupo[0]->nivel); ?><?php echo e($grupo[0]->modulo); ?></h4>
        <h6 class="text-dark"><?php echo e($grupo[0]->edificio); ?><?php echo e($grupo[0]->aula); ?> <?php echo e($grupo[0]->hora); ?></h6>
        <h6 class="text-dark"><?php echo e($periodo_actual[0]->descripcion); ?> <?php echo e($periodo_actual[0]->anio); ?></h6>   
    </div>
</div>
    <div class="container-fluid m--t"> 
        <div class="text-right">
            <a href="<?php echo e(back()); ?>" class="btn btn-outline-primary btn-sm mt-4">
                <span>
                    <i class="fas fa-reply"></i> &nbsp; Regresar
                    <input type="hidden" name="periodo" value="<?php echo e($grupo[0]->periodo); ?>">
                </span>
            </a>
        </div>
        <div class="row">
           
            <div class="col-md">
                    
            </div>
            
            </div>
        <div class="card-body">
            <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="pl-lg-4"> <?php $nivel =  $grupo[0]->nivel.$grupo[0]->modulo ?>
            <form method="post" action="<?php echo e(route('guardarLista')); ?>" autocomplete="off">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <input type="hidden" name="grupo" value="<?php echo e($grupo[0]->id_grupo); ?>">
                <input type="hidden" name="periodo" value="<?php echo e($grupo[0]->periodo); ?>">
                <input type="hidden" name="cupo" value="<?php echo e($grupo[0]->cupo); ?>">
                <div class="row">
                        <div class="col-xl" >
                                <div class="card shadow " >
                                    <div class="card-header border-3">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h6 class="heading-small text-muted mb-4"><?php echo e(__('Estudiantes Posibles a Inscripción')); ?></h6>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    
                                        <table class="table align-items-center table-flush th" id="datatable"> 
                                            <thead class="thead-light">
                                                <tr>
                                                    <th scope="col">Número <br> de Control</th>
                                                    <th scope="col">Nombre</th>
                                                    <th scope="col">Inscribir</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $aprobados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                <th scope="row">
                                                    <?php echo e($alumno->num_control); ?>

                                                </th>
                                                <th scope="row">
                                                    <?php echo e($alumno->nombres); ?> <?php echo e($alumno->ap_paterno); ?> <?php echo e($alumno->ap_materno); ?>

                                                </th>
                                                <td scope="row">
                                                    <span id="alumnoid" data-alumnoid="<?php echo e($alumno->num_control); ?>" data-nombre="<?php echo e($alumno->nombres); ?> <?php echo e($alumno->ap_paterno); ?> <?php echo e($alumno->ap_materno); ?>">
                                                        <input type="checkbox" name="inscribir[]" value="<?php echo e($alumno->num_control); ?>">
                                                    </span>
                                                </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    
                                </div>
                            </div>
            
                    
                </div>  
                <div class="text-center">
                    <button type="submit" class="btn btn-primary mt-4" id="guardar"><?php echo e(__('Inscribir Estudiantes')); ?></button>
                </div>
            </form>
        </div>
        <br><br>
        <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<div class="col-md-4">
        <div class="modal fade" id="modal-notification" tabindex="-1" role="dialog" aria-labelledby="modal-notification" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-" role="document">
                <div class="modal-content bg-gradient-white">
                    
                    <div class="modal-header">
                        <h6 class="modal-title" id="modal-title-notification">¡Espera!</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        
                    </div>
                    <div class="modal-body">
                        
                        <div class="py-3 text-center">
                                <i class="fas fa-times fa-3x" style="color:#CD5C5C;"></i>
                            <h4 class="heading mt-4">¡El grupo esta lleno!</h4>
                            <p>Ya no puedes agregar m&aacute;s estudiantes al grupo, verifica que sean los que realmente quieres agregar, o agrega en un grupo distinto.</p>
                            <input type="hidden" name="alumno_id" id="alumno_id" value="">
                        </div>
                        
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger text-center ml-auto" data-dismiss="modal">Ok</button> 
                    </div>
                </div>
            </div>
        </div>
            </div>
            

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/inscripciones/listaGrupo.blade.php ENDPATH**/ ?>