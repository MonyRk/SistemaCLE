<!DOCTYPE html>
<html>
<head>
<style>
/* table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  table-layout: fixed;
}


th, td {
    width: 100px;
    word-wrap: break-word;
} */
table, th, td{
    table-layout: fixed;
    border: 1px solid black;
    border-collapse: collapse;
    /* width: 250px; */
}

.col-small {
    width: 10%;
    word-wrap: break-word;
    /* border-collapse: collapse; */
}
.col-med {
    width: 30%;
    word-wrap: break-word;
    /* border-collapse: collapse; */
}
.col-17 {
    width: 17%;
    word-wrap: break-word;
    /* border-collapse: collapse; */
}

.col-3 {
    width: 3%;
    word-wrap: break-word;
    /* border-collapse: collapse; */
}
</style>

</head>
<body>


<div class="text-center">
    <img src="<?php echo e(asset('argon')); ?>/img/brand/cabeceraSM.png" alt="cabecera" title="cabecera">
</div>
<br><br>


<table style="width:100%">
    <thead>
        <tr>
            <th scope="col">Group: <?php echo e($datosGrupo[0]->grupo); ?></th>
            <th scope="col">Level: <?php echo e($datosGrupo[0]->nivel); ?><?php echo e($datosGrupo[0]->modulo); ?></th>
            <th scope="col"><?php echo e($datosGrupo[0]->descripcion); ?> <?php echo e($datosGrupo[0]->anio); ?></th>
        </tr>
        <tr>
            <th scope="col">Teacher: <?php echo e($datosGrupo[0]->nombres); ?> <?php echo e($datosGrupo[0]->ap_paterno); ?> <?php if($datosGrupo[0]->ap_materno!=null): ?><?php echo e($datosGrupo[0]->ap_materno); ?> <?php endif; ?></th>
            <th scope="col"><?php echo e($datosGrupo[0]->hora); ?></th>
            <th scope="col"><?php echo e($datosGrupo[0]->modalidad); ?></th>
        </tr>
    </thead>
</table>
<br>
<table style="width:100%" id="datatable">
                <thead class="thead-light">
                    <tr>
                        <th scope="col" class="col-3">No.</th>
                        <th scope="col" class="col-small">No. de <br>Control</th>
                        <th scope="col" class="col-med">Student's Name</th>
                        <th scope="col" class="col-17">Degree</th>
                        <th scope="col" style="width:50%" colspan="25">Month:</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $i=1;
                    ?>
                    <?php $__currentLoopData = $alumnos_en_el_grupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    
                    <tr>
                        <td>
                            <?php echo e($i); ?>

                        </td>
                        <td scope="row">
                            <?php echo e($alumno->num_control); ?>

                        </td>
                        <td scope="row">
                           <?php echo e($alumno->nombres); ?> <?php echo e($alumno->ap_paterno); ?> <?php if($alumno->ap_materno != null): ?> <?php echo e($alumno->ap_materno); ?> <?php endif; ?>
                        </td>
                        <td scope="row">
                            <?php if($alumno->carrera=='Ingeniería en Sistemas Computacionales'): ?>Ing. Sist. Com. 
                            <?php else: ?>
                                <?php if($alumno->carrera=='Ingeniería en Gestión Empresarial'): ?>Ing. Gesti&oacute;n E.
                                <?php else: ?>
                                    <?php if($alumno->carrera=='Licenciatura en Administración'): ?>Lic. Admin.
                                    <?php else: ?>    
                                        <?php echo e($alumno->carrera); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                        </td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        <td scope="row"></td>
                        
                    </tr>
                    <?php
                        $i++
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

</body>
</html>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        
                        
                    </div>
                </div>
            </div>
        </div>

        
    </div>
</body>
</html><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/pdf/listaGrupo.blade.php ENDPATH**/ ?>