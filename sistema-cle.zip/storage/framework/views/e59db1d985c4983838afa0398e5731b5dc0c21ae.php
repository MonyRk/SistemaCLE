<?php $__env->startSection('sidebar'); ?>
<?php
$usuarioactual = \Auth::user();
?>
<?php if($usuarioactual->tipo == 'coordinador'): ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('layouts.navbars.sidebarDocentes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="header pb-2 pt-5 pt-lg-8 d-flex align-items-center text-center" >
        <div class="col-lg col-md">
                <h4 class="text-dark">Editar Docente</h4>
            </div>
</div>

    <div class="container-fluid m--t">
            <div class="text-right">
                    <a href="<?php echo e(back()); ?>" class="btn btn-outline-primary btn-sm mt-4">
                        <span>
                            <i class="fas fa-reply"></i> &nbsp; Regresar
                        </span>
                    </a>
                </div>
                <div>
                    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
    <div class="card-body ">

        
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    <strong>No pudimos agregar los datos, <br> por favor, verifica la información</strong>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>  
                </div>    
             
            <?php else: ?> 
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                     <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>                           
            <?php endif; ?>

        <form method="post" action="<?php echo e(url("docentes/{$docente[0]->id_docente}")); ?>" autocomplete="off" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Personal')); ?></h6>
            
            <p class="text-muted">La informaci&oacute;n proporcionada en &eacute;sta p&aacute;gina web ser&aacute; utilizada para fines 
                    acad&eacute;micos y s&oacute;lo por la Coordinaci&oacute;n de Lenguas Extranjeras.</p>
            <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                   
                </div>
            <?php endif; ?>

            <div class="pl-lg-4">
                <div class="row">
                    <div class="col-md">
                        <label class="form-control-label" for="input-name"><?php echo e(__('Nombre(s)')); ?></label>
                        <input type="text" name="name" id="input-name" class="form-control" placeholder="" value="<?php echo e(old('name', $docente[0]->nombres)); ?>"  autofocus>
                    </div>
                    <div class="col-md">
                        <label class="form-control-label" for="input-apPaterno"><?php echo e(__('Apellido Paterno')); ?></label>
                        <input type="text" name="apPaterno" id="input-apPaterno" class="form-control" placeholder="" value="<?php echo e(old('apPaterno', $docente[0]->ap_paterno)); ?>"  >
                    </div>
                    <div class="col-md">
                        <label class="form-control-label" for="input-apMaterno"><?php echo e(__('Apellido Materno')); ?></label>
                        <input type="text" name="apMaterno" id="input-apMaterno" class="form-control" placeholder="" value="<?php echo e(old('apMaterno', $docente[0]->ap_materno)); ?>"  >
                    </div>
                </div>
                
                <br>

                <div class="form-row">
                    <div class="form-group col-md-5">
                        <label class="form-control-label" for="input-curp"><?php echo e(__('CURP')); ?></label>
                        <input type="text" class="form-control" name="curp" id="input-curp" value="<?php echo e(old('curp', $docente[0]->curp)); ?>" <?php if($usuarioactual->tipo != 'coordinador'): ?> readonly <?php endif; ?>>
                    </div>
                    <div class="form-group col-md-2">
                        <label class="form-control-label" for="input-edad"><?php echo e(__('Edad')); ?></label>
                        <input type="text" class="form-control" name="edad" id="input-edad" value="<?php echo e(old('edad', $docente[0]->edad)); ?>">
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-sexo" ><?php echo e(__('Sexo')); ?></label>
                        <div class="row">            
                            <div class="custom-control custom-radio">
                                <input type="radio" id="sexof" name="sexo"  <?php if($docente[0]->sexo ='F'): ?> checked <?php endif; ?> value = <?php echo e(old('sexo',$docente[0]->sexo)); ?> class="custom-control-input">
                                <label class="custom-control-label" for="sexof">&nbsp&nbsp&nbsp&nbsp&nbspFemenino</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" id="sexom" name="sexo" <?php if($docente[0]->sexo ='M'): ?> checked <?php endif; ?> value = <?php echo e(old('sexo',$docente[0]->sexo)); ?> class="custom-control-input">
                                <label class="custom-control-label" for="sexom">&nbsp&nbsp&nbsp&nbsp&nbspMasculino</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-calle"><?php echo e(__('Dirección')); ?></label>
                        <input type="text" name="calle" id="input-calle" class="form-control" placeholder="Calle" value="<?php echo e(old('calle', $docente[0]->calle)); ?>"  >
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-numero"><?php echo e(__('')); ?></label>
                        <input type="text" name="numero" id="input-numero" class="form-control" placeholder="Número" value="<?php echo e(old('numero', $docente[0]->numero)); ?>"  >
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-colonia"><?php echo e(__(' ')); ?></label>
                        <input type="text" name="colonia" id="input-colonia" class="form-control" placeholder="Colonia" value="<?php echo e(old('colonia', $docente[0]->colonia)); ?>"  >
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-municipio"><?php echo e(__(' ')); ?></label>
                        <select id="input-municipio" class="form-control" name="municipio">
                            
                                <?php echo e($nm = App\Municipio::select('id','nombre_municipio')->where('id',$docente[0]->municipio)->pluck('nombre_municipio')); ?>

                            
                        <option selected value="<?php echo e(old('municipio', $docente[0]->municipio)); ?>"><?php echo e($nm[0]); ?> </option>
                        <?php $__empty_1 = true; $__currentLoopData = $nombres_municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($mun); ?>"><?php echo e($mun); ?></option>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                        
                        </select>
                                         
                    </div>
                    <div class="form-group col-md">
                            <label class="form-control-label" for="input-cp"><?php echo e(__(' ')); ?></label>
                            <input type="text" name="cp" id="input-cp" class="form-control" placeholder="C.P." value="<?php echo e(old('cp', $docente[0]->cp)); ?>"  >
                        </div> 

                </div>
                <div class="row">
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-telefono"><?php echo e(__('Teléfono')); ?></label>
                        <input type="text" name="telefono" id="input-telefono" class="form-control" placeholder="" value="<?php echo e(old('telefono', $docente[0]->telefono)); ?>"  >
                    </div>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-email"><?php echo e(__('Email')); ?></label>
                        <input type="email" name="email" id="input-email" class="form-control form-control-alternative" placeholder=""value="<?php echo e(old('email',$email)); ?>"  >
                    </div>
                </div>
        
        
            </div>

            <hr class="my-4" />
            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Profesional')); ?></h6>
            
            <div class="pl-lg-4 prof">
                    <div class="form-row">  
                            <div class="form-group col-md-6">
                                <label class="form-control-label" for="input-estudios"><?php echo e(__('Grado de Estudios')); ?></label>
                                <input class="form-control" type="text" id="input-estudios" name="estudios" value="<?php echo e(old('estudios',$docente[0]->grado_estudios)); ?>">
                                
                            </div>
                            <div class="form-group col-md" <?php if($usuarioactual->tipo != 'coordinador'): ?>style = "display:none;" <?php else: ?> style="display:block" <?php endif; ?>>
                                <label class="form-control-label" for="input-estatus"><?php echo e(__('Estatus')); ?></label>
                                <select id="input-estatus" class="form-control" name="estatus">
                                <option value="<?php echo e(old('estatus',$docente[0]->estatus)); ?>" selected><?php echo e(old('estatus',$docente[0]->estatus)); ?></option>
                                <option value="Activo"><?php echo e(__('Activo')); ?></option>
                                <option value="Inactivo"><?php echo e(__('Inactivo')); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md">
                                <label class="form-control-label" for="dominio"><?php echo e(__('Certificación de Dominio del Idioma')); ?></label>
                                <input type="input" name="dominio" id="dominio" class="form-control form-control-alternative" placeholder=""value="<?php echo e(old('dominio')); ?>"  >
                            </div>
                            <div class="form-group col-md">
                                <label class="form-control-label" for="curso"><?php echo e(__('Curso de Entrenamiento para Profesores')); ?></label>
                                <input type="input" name="curso" id="curso" class="form-control form-control-alternative" placeholder=""value="<?php echo e(old('curso')); ?>"  >
                            </div>                                    
                        </div>
                        <div class="form-row">
                            <div class="field_wrapper form-group col-md">
                                <div>
                                    <label class="form-control-label" for="didactica"><?php echo e(__('Certificaciones de Didáctica')); ?></label>
                                    <input type="text" class="form-control form-control-alternative" id="didactica" name="didactica[]" value="<?php echo e(old('didactica')); ?>"/>
                                    <a href="javascript:void(0);" class="add_button" title="Add field"><i class="fas fa-plus text-info"></i></a>
                                </div>
                            </div>
                            <div class="form-group col-md">
                                <label class="form-control-label" for="experiencia"><?php echo e(__('Experiencia Docente')); ?></label>
                                <input type="input" name="experiencia" id="experiencia" class="form-control form-control-alternative" placeholder="Años"value="<?php echo e(old('experiencia')); ?>"  >
                            </div>
                        </div>
                        <label class="form-control-label" for="actualizacion"><?php echo e(__('Actualizaciones Docentes')); ?></label>
                        <div class="form-row">
                            <div class="form-group col-md">
                                <input type="input" name="actualizacion[]" id="actualizacion" class="form-control form-control-alternative" placeholder=""value="<?php echo e(old('experiencia')); ?>"  >
                            </div>
                            <div class="form-group col-md">
                                <input type="input" name="actualizacion[]" id="actualizacion" class="form-control form-control-alternative" placeholder=""value="<?php echo e(old('experiencia')); ?>"  >
                            </div>
                            <div class="form-group col-md">
                                <input type="input" name="actualizacion[]" id="actualizacion" class="form-control form-control-alternative" placeholder=""value="<?php echo e(old('experiencia')); ?>"  >
                            </div>
                        </div>
                        <div class="form-row" <?php if($usuarioactual->tipo != 'coordinador'): ?>style = "display:none;" <?php else: ?> style="display:block" <?php endif; ?>>
                            <div class="form-group col-md-6">
                                <label class="form-control-label" for="input-rfc"><?php echo e(__('RFC')); ?></label>
                                <div class="form-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="input-rfc" aria-describedby="input-rfc" name="rfc" value="<?php echo e(old('rfc',$docente[0]->rfc)); ?>" lang="es">
                                        <label class="custom-file-label" for="input-rfc"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row" <?php if($usuarioactual->tipo != 'coordinador'): ?>style = "display:none;" <?php else: ?> style="display:block" <?php endif; ?>>
                            <div class="form-group col-md-6">
                                <label class="form-control-label" for="input-titulo"><?php echo e(__('Título')); ?></label>
                                <div class="form-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="input-titulo" aria-describedby="input-titulo" name="titulo" value="<?php echo e(old('titulo',$docente[0]->titulo)); ?>">
                                        <label class="custom-file-label" for="input-titulo"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row" <?php if($usuarioactual->tipo != 'coordinador'): ?>style = "display:none;" <?php else: ?> style="display:block" <?php endif; ?>>
                            <div class="form-group col-md-6">
                                <label class="form-control-label" for="input-cedula"><?php echo e(__('Cédula Profesional')); ?></label>
                                <div class="form-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="input-cedula" aria-describedby="input-cedula" name="cedula" value="<?php echo e(old('cedula',$docente[0]->ced_prof)); ?>">
                                        <label class="custom-file-label" for="input-cedula"></label>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="form-row" <?php if($usuarioactual->tipo != 'coordinador'): ?>style = "display:none;" <?php else: ?> style="display:block" <?php endif; ?>>
                            <div class="form-group col-md-6">
                                <label class="form-control-label" for="input-certificaciones"><?php echo e(__('Certificaciones')); ?></label>
                                <div class="form-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="input-certificaciones" aria-describedby="input-certificaciones" name="certificaciones[]" value="<?php echo e(old('certificaciones')); ?>" multiple>
                                        <label class="custom-file-label" for="input-certificaciones" data-browse="Bestand kiezen"></label>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        

                        <hr class="my-4" />
            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información de Usuario')); ?></h6>
            <div class="form-group col-md-3">
                <label class="form-control-label" for="input-contrasenia"><?php echo e(__('Reestablecer Contraseña?*')); ?></label>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" id="input-contrasenia" name="contrasenia" onchange="comprobar2(this);" value="true" class="custom-control-input">
                    <label class="custom-control-label" for="input-contrasenia">o</label>
                </div>
            </div>
            <div id="reestablecer-contrasenia" style="display:none;">
                
                <div class="form-group col-xl-4">
                    <label class="form-control-label" for="input-password"><?php echo e(__('Nueva Contraseña')); ?></label>
                    <input type="password" name="password" id="input-password" class="form-control form-control-alternative" value="" >
                </div>
                <div class="form-group col-xl-4">
                    <label class="form-control-label" for="input-password-confirmation"><?php echo e(__('Confirmar Nueva Contraseña')); ?></label>
                    <input type="password" name="password_confirmation" id="input-password-confirmation" class="form-control form-control-alternative" value="" >
                </div>
            </div>
            <p class="text-muted">*El reestablecimiento de la contraseña no es obligatorio al ver o actualizar otro dato</p>          
        </div>
    </div>

            <div class="text-center">
                <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Actualizar')); ?></button>
            </div>
        </form>
    </div>

    <script>
            function comprobar2(obj)
            {   
                if (obj.checked){
                    document.getElementById('reestablecer-contrasenia').style.display = "";
                } else{
                    document.getElementById('reestablecer-contrasenia').style.display = "none";
                }     
            }

    
        </script>

    <br><br>
           <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->startSection('script'); ?>
    <script>
        // function llenar(){
        //     var alumn_id = 'hola.pdf';
        //     $('.prof').find('#input-cedula').val(alumn_id);
        // });
        // }
        // poner los datos en input file
        $('.custom-file-input').on('change', function(event) {
            var inputFile = event.currentTarget;
            $(inputFile).parent()
                .find('.custom-file-label')
                .html(inputFile.files[0].name);
        });


        // PARA AGREGAR CAMPOS
        $(document).ready(function(){
        var maxField = 10; //Input fields increment limitation
        var addButton = $('.add_button'); //Add button selector 
        var wrapper = $('.field_wrapper'); //Input field wrapper
        var fieldHTML = '<div><input type="text" name="didactica[]" value="" class="form-control form-control-alternative"/><a href="javascript:void(0);" class="remove_button" title="Remove field"><i class="fas fa-times text-danger "></i></div>'; //New input field html 
        var x = 1; //Initial field counter is 1
        $(addButton).click(function(){ //Once add button is clicked
            if(x < maxField){ //Check maximum number of input fields
                x++; //Increment field counter
                $(wrapper).append(fieldHTML); // Add field html
            }
        });
        $(wrapper).on('click', '.remove_button', function(e){ //Once remove button is clicked
            e.preventDefault();
            $(this).parent('div').remove(); //Remove field html
            x--; //Decrement field counter
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/docentes/editDocente.blade.php ENDPATH**/ ?>