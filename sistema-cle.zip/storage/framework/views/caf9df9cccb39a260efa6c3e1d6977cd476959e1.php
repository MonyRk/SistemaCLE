<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Datos Estadisticos</title>

    <style>
        /* .table, th, td, tr {
            table-layout: fixed;
            border: 1px solid black;
            border-collapse: collapse;

        } */

        /* * {
    font-size: x-small;
} */

th {
    background-color: #f7f7f7;
    border-color: #959594;
    border-style: solid;
    border-width: 1px;
    text-align: center;
}

.bordered td {
    border-color: #959594;
    border-style: solid;
    border-width: 1px;
}

table {
    border-collapse: collapse;
    /* padding-top: 40%; */
}

/* Para sobrescribir lo que está en div-table.css */
.divTableCell,
.divTableHead {
    padding: 0px !important;
    border: 0px !important;
}
        .divTable {
    display: table;
    width: 100%;
}

.divTableRow {
    display: table-row;
}

.divTableHeading {
    background-color: #eee;
    display: table-header-group;
}

.divTableCell,
.divTableHead {
    border: 1px solid #999999;
    display: table-cell;
    padding: 3px 10px;
}

.divTableHeading {
    background-color: #eee;
    display: table-header-group;
    font-weight: bold;
}

.divTableFoot {
    background-color: #eee;
    display: table-footer-group;
    font-weight: bold;
}

.divTableBody {
    display: table-row-group;
}
thead:before, thead:after { display: none; }
tbody:before, tbody:after { display: none; }
    </style>
</head>

<body >

    <div align="center">
        <img src="<?php echo e(asset('argon')); ?>/img/brand/cabeceraSM.png" alt="cabecera" title="cabecera">
    </div>

   <div>
        <h3 class="text-dark" align="center">Ingresos Estimados de la CLE del Periodo <?php echo e($periodo[0]->descripcion); ?> <?php echo e($periodo[0]->anio); ?></h3>
    <h2 class="text-center mt-3" align="center">$ <?php echo e($ingresos*814); ?>.00</h2>

    <h3 class="mt-6 text-center" align="center">Total de Estudiantes inscritos durante el periodo <?php echo e($periodo[0]->descripcion); ?> <?php echo e($periodo[0]->anio); ?></h3>
    <h2 class="text-center mt-3" align="center"> <?php echo e($ingresos); ?></h2>

    <h3 class="text-dark" align="center">Datos Estadisticos del Periodo <?php echo e($periodo[0]->descripcion); ?> <?php echo e($periodo[0]->anio); ?></h3>

   </div>


<div class="divTable">
    <div class="divTableBody">
        <div class="divTableRow">
            <div class="divTableCell">
                    <table  cellspacing="0" cellpadding="0" align="center" border="1" style="padding-top:100px;">
                            <thead>
                                <tr colspan="2" ><h3 align="center">Estudiantes por Carrera</h3></tr>
                                <tr >
                                    <th>Carrera</th>
                                    <th>N&uacute;m. Estudiantes</th>
                                </tr>
                            </thead>
                            <tbody class="bordes">
                                <?php
                                $i=0;
                                ?>
                                <?php $__currentLoopData = $nombre_carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bordes">
                                    <td class="bordes"><?php echo e($carrera); ?></th>
                                    <td class="bordes" align="center"><?php echo e($carreras[$i]); ?></td>
                                </tr>
                                <?php
                                $i++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    
            </div>
        </div>
    </div>
</div>

        
    

</body>

</html><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/pdf/estadisticapdf.blade.php ENDPATH**/ ?>