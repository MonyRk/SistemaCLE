<?php $__env->startSection('titlecreate'); ?>
    Agregar Estudiante
<?php $__env->stopSection(); ?>
<?php $__env->startSection('regresar'); ?>
    <?php echo e(redirect()->back()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('action'); ?>
<?php echo e(url("guardarEstudiante")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('nombreTipodeInformacion'); ?> 
    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Escolar')); ?></h6>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('informacionporTipo'); ?>
    <div class="form-row">
        <div class="form-group col-md-4" >
            <label class="form-control-label" for="input-numControl"><?php echo e(__('Número de Control')); ?></label>
            <input type="text" name="numControl" id="input-numControl" class="form-control" placeholder="" value="<?php echo e(old('numControl')); ?>" data-toggle="tooltip" data-placement="bottom" title="Aseg&uacute;rate de escribir correctamente el N&uacute;mero de Control">
        </div>
        <div class="form-group col-md-6">
            <label class="form-control-label" for="input-carrera"><?php echo e(__('Carrera')); ?></label>
            <select id="input-carrera" class="form-control" name="carrera">
            <option selected value="<?php echo e(old('carrera')); ?>"><?php echo e(old('carrera')); ?></option>
            <option value="Ingeniería Eléctrica"><?php echo e(__('Ing. Eléctrica')); ?></option>
            <option value="Ingeniería Electrónica"><?php echo e(__('Ing. Electrónica')); ?></option>
            <option value="Ingeniería Civil"><?php echo e(__('Ing. Civil')); ?></option>
            <option value="Ingeniería Mecánica"><?php echo e(__('Ing. Mecánica')); ?></option>
            <option value="Ingeniería Industrial"><?php echo e(__('Ing. Industrial')); ?></option>
            <option value="Ingeniería Química"><?php echo e(__('Ing. Química')); ?></option>
            <option value="Ingeniería en Gestión Empresarial"><?php echo e(__('Ing. Gestión Empresarial')); ?></option>
            <option value="Ingeniería en Sistemas Computacionales"><?php echo e(__('Ing. Sistemas Computacionales')); ?></option>
            <option value="Licenciatura en Administración"><?php echo e(__('Lic. Administración')); ?></option>
            </select>
        </div>
        <div class="form-group col-md-2">
                <label class="form-control-label" for="input-semestre"><?php echo e(__('Semestre')); ?></label>
                <select  id="input-semestre" class="form-control" name="semestre">
                <option selected value="<?php echo e(old('semestre')); ?>"><?php echo e(old('semestre')); ?></option>
                    <?php for($i = 1; $i <= 12; $i++): ?>
                        <option value="<?php echo e($i); ?>"><?php echo e(($i)); ?></option>
                    <?php endfor; ?> 
                </select>
        </div>
        
        </div>
        <div class="form-row">
            <div class="form-group col-md-3">
                <label class="form-control-label" for="input-sexo"><?php echo e(__('Examen de Ubicación')); ?></label>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" id="examen" name="examen" onchange="comprobar(this);" value="true" class="custom-control-input">
                    <label class="custom-control-label" for="examen">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Realiz&oacute; examen</label>
                </div>
            </div>
            <div class="form-group col-md-3" id="inicial" style="display:none">
                <label class="form-control-label" for="input-nivel"><?php echo e(__('Nivel Donde Inicia')); ?></label>
                <select id="input-nivel" class="form-control" name="nivel">
                    <option selected></option>
                        <?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nivel->nivel); ?><?php echo e($nivel->modulo); ?>"><?php echo e($nivel->nivel); ?><?php echo e($nivel->modulo); ?>&nbsp;-&nbsp; <?php echo e($nivel->idioma); ?></option>                             
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>                  
            </div>  
                
            
        </div>
    <script>
            function comprobar(obj)
               {   
                   if (obj.checked){
                   
               document.getElementById('inicial').style.display = "";
               } else{
                   
               document.getElementById('inicial').style.display = "none";
               }     
               }
           </script>   
<?php $__env->stopSection(); ?>



<?php echo $__env->make('viewsBase.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/alumnos/createAlumno.blade.php ENDPATH**/ ?>