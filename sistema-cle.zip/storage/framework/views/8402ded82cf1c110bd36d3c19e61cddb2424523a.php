<!DOCTYPE html>
<html>

<head>
    <style>
        table,
        th,
        td {
            table-layout: fixed;
            border: 1px solid black;
            border-collapse: collapse;
            
        }

        .alto-30 {
            height: 30px;
        }

        .alto-50 {
            height: 50px;
        }
        .ancho-30{
            width: 30px;
        }

        #caja {
            width: 100%;
            height: 50px;
        }

        #texto-uno {
            float: left;
            padding-left: 8%;  
            line-height: 10%;
            text-transform: uppercase
        }

        #texto-dos {
            float: right;
            padding-right: 5%;
            line-height: 20%;
            text-transform: uppercase
        }
    </style>

</head>

<body>

    
    
    <br><br>
<?php
    $i=0;
?>
    <table style="width:100%">
       <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <thead>
                
            </thead>
            <tbody>
                <tr>
                    <th scope="col">No.</th>
                    <th scope="col"> Nombre</th>
                    <th scope="col" class="width-30">Sexo</th>
                    <th scope="col" class="width-30">Edad</th>
                </tr>
                <tr class="text-center">
                    <td scope="col" class="alto-50" align="center"><?php echo e($i++); ?></td>
                    <td scope="col" class="alto-50" align="center"><?php echo e($docente->nombres); ?> <?php echo e($docente->ap_paterno); ?> <?php echo e($docente->ap_materno); ?></td>
                    <td scope="col" class="alto-50 width-30" align="center"><?php echo e($docente->sexo); ?></td>
                    <td scope="col" class="alto-50 width-30" align="center"><?php echo e($docente->edad); ?></td>
                </tr>
                <tr>
                    <th scope="col" class="alto-50" align="center">&Uacute;ltimo Grado de Estudios</th>
                    <th scope="col" class="alto-50" align="center">Certificaci&oacute;n del Dominio del Idioma</th>
                    <th scope="col" class="alto-50" align="center" colspan="2">Curso de Entrenamiento para Profesores (Teacher's Training Course)</th>
                </tr>
                <tr>
                    <td scope="col" class="alto-50" align="center"><?php echo e($docente->grado_estudios); ?></td>
                    <td scope="col" class="alto-50" align="center"><?php echo e($docente->dominio_idioma); ?></td>
                    <td scope="col" class="alto-50" align="center" colspan="2"><?php echo e($docente->curso); ?></td>
                </tr>
                <tr>
                    <th scope="col" class="alto-50" align="center">Certificaciones de Did&aacute;ctica</th>
                    <th scope="col" class="alto-50" align="center">Años de Experiencia Docente</th>
                    <th scope="col" class="alto-50" align="center" colspan="2">3 &Uacute;ltimas Actualizaciones Docentes</th>
                </tr>
                <tr>
                    <td scope="col" class="alto-50" align="center">
                        <?php $didacticas = ""; $didacticas = explode(';',$docente->didactica); ?>
                        <?php $__currentLoopData = $didacticas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre_didactica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($nombre_didactica); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td scope="col" class="alto-50" align="center"><?php echo e($docente->experiencia); ?></td>
                    <td scope="col" class="alto-50" align="center" colspan="2">
                        <?php $actualizaciones = ""; $actualizaciones = explode(';',$docente->actualizacion); ?>
                        <?php $__currentLoopData = $actualizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre_actualizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($nombre_actualizacion); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
                <br>
            </tbody>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</body>

</html><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/pdf/plantilla.blade.php ENDPATH**/ ?>