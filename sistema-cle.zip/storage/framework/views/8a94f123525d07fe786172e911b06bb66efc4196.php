<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    use Carbon\Carbon;
?>
<div class="container-fluid m--t">
    <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center" >
        <div class="col-lg col-md">
            <h4 class="text-dark">Exámenes de Ubicaci&oacute;n Periodo: <?php echo e($periodo_actual[0]->descripcion); ?> <?php echo e($periodo_actual[0]->anio); ?></h4>
        </div>
    </div>
    <div class="card-body">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="text-right">
        
        <a href="<?php echo e(back()); ?>" class="btn btn-outline-primary btn-sm mt-4">
            <span>
                <i class="fas fa-reply"></i> &nbsp; Regresar
            </span>
        </a>
    </div>
    <form action="<?php echo e(route('verificarExamenes')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="row mt-3">
            <div class="col-xl">
                <div class="col-xl">
                    <div class="card shadow ">
                        <div class="card-header border-3">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h5>Exámenes Registrados</h5>
                                </div>
                                
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush th" id="datatable">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Número de <br>Control</th>
                                        <th scope="col">Nombre</th>
                                        <th scope="col">Nivel</th>
                                        <th scope="col">Verificar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $alumnos_ubicados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($alumno->num_control); ?>

                                            </td>
                                            <td>
                                                <?php echo e($alumno->nombres); ?> <?php echo e($alumno->ap_paterno); ?> <?php if($alumno->ap_materno): ?> <?php echo e($alumno->ap_materno); ?> <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($alumno->nivel_inicial); ?>

                                            </td>
                                            <td>
                                                <div class="custom-control custom-control-alternative custom-checkbox">
                                                    <input class="custom-control-input" id="<?php echo e($alumno->num_control); ?>" name="verificado[]" type="checkbox" value="<?php echo e($alumno->num_control); ?>">
                                                    <label class="custom-control-label" for="<?php echo e($alumno->num_control); ?>">E</label>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center">
            <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Guardar Verificados')); ?></button>
        </div>
    </form>
    <br><br>
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/cursos/verificarExamen.blade.php ENDPATH**/ ?>