<?php $__env->startSection('regresar'); ?>
<?php echo e(route('verDocentes')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('informacion'); ?>
<hr class="my-4"/>
    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Profesional')); ?></h6>
    <div>
        <div class="row">
            <div class="col-xl col-lg-6">
                    <div class="card card-stats mb-4 mb-xl">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <span class="card-title"><?php echo e(__('Grado de Estudios: ')); ?></span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="">
                                    <p class="card-text font-weight-bold"><?php echo e($datos[0]->grado_estudios); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl col-lg-6">
                    <div class="card card-stats mb-4 mb-xl">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <span class="card-title"><?php echo e(__('RFC : ')); ?></span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="">
                                    <a href= "<?php echo e(route('verRfc',[$datos[0]->id_docente,$datos[0]->rfc])); ?>" target="_blank" class="card-text font-weight-bold text-dark"><u><?php echo e($datos[0]->rfc); ?></u></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <div class="row">
            <div class="col-xl col-lg-6">
                <div class="card card-stats mb-4 mb-xl">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <span class="card-title"><?php echo e(__('Título: ')); ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="">
                                <a href= "<?php echo e(route('verTitulo',[$datos[0]->id_docente,$datos[0]->titulo])); ?>" target="_blank" class="card-text font-weight-bold text-dark"><u><?php echo e($datos[0]->titulo); ?></u></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl col-lg-6">
                <div class="card card-stats mb-4 mb-xl">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <span class="card-title"><?php echo e(__('Cédula Profesional: ')); ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="">
                                <a href= "<?php echo e(route('verCedula',[$datos[0]->id_docente,$datos[0]->ced_prof])); ?>" target="_blank" class="card-text font-weight-bold text-dark"><u><?php echo e($datos[0]->ced_prof); ?></u></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl col-lg-6">
                <div class="card card-stats mb-4 mb-xl">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <span class="card-title"><?php echo e(__('Certificaciones: ')); ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="">
                                <?php if($datos[0]->certificaciones != null): ?>
                                    <?php $documentos = ""; $documentos = explode(',',$datos[0]->certificaciones); ?>
                                    <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('verCertificaciones',[$datos[0]->id_docente,$certificacion])); ?>" class="card-text font-weight-bold text-dark"><u><?php echo e($certificacion); ?></u></a><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl col-lg-6">
                <div class="card card-stats mb-4 mb-xl">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <span class="card-title"><?php echo e(__('Estatus: ')); ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="">
                                <p class="card-text font-weight-bold"><?php echo e($datos[0]->estatus); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl col-lg">
                <div class="card card-stats mb-4 mb-xl">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <span class="card-title"><?php echo e(__('Certificacion de Dominio del Idioma: ')); ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="">
                                <?php if($datos[0]->dominio_idioma != null): ?>
                                    <p class="card-text font-weight-bold"><?php echo e($datos[0]->dominio_idioma); ?></p>
                                    
                                <?php endif; ?>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl col-lg">
                <div class="card card-stats mb-4 mb-xl">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <span class="card-title"><?php echo e(__('Curso de Entrenamiento para Profesores: ')); ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="">
                                <?php if($datos[0]->curso != null): ?>
                                    <p class="card-text font-weight-bold"><?php echo e($datos[0]->curso); ?></p>
                                    
                                <?php endif; ?>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl col-lg">
                <div class="card card-stats mb-4 mb-xl">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <span class="card-title"><?php echo e(__('Años de Experiencia Docente: ')); ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="">
                                <?php if($datos[0]->experiencia != null): ?>
                                    <p class="card-text font-weight-bold"><?php echo e($datos[0]->experiencia); ?></p>
                                    
                                <?php endif; ?>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl col-lg">
                <div class="card card-stats mb-4 mb-xl">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <span class="card-title"><?php echo e(__('Certificaciones de Didáctica: ')); ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="">
                                <?php if($datos[0]->didactica != null): ?>
                                    
                                    <?php $didactica = ""; $didactica = explode(';',$datos[0]->didactica); ?>
                                    <?php $__currentLoopData = $didactica; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre_didactica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p  class="card-text font-weight-bold text-dark"><?php echo e($nombre_didactica); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl col-lg">
                <div class="card card-stats mb-4 mb-xl">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <span class="card-title"><?php echo e(__('Acciones de Actualización Docente: ')); ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="">
                                <?php if($datos[0]->actualizacion != null): ?>
                                    
                                    <?php $actualizaciones = ""; $actualizaciones = explode(';',$datos[0]->actualizacion); ?>
                                    <?php $__currentLoopData = $actualizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre_actualizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p  class="card-text font-weight-bold text-dark"><?php echo e($nombre_actualizacion); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('viewsBase.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/docentes/showDocente.blade.php ENDPATH**/ ?>