<?php $__env->startSection('regresar'); ?>
    <?php echo e(route('verDocentes')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('titlecreate'); ?>
    Agregar Docente
<?php $__env->stopSection(); ?>
<?php $__env->startSection('action'); ?>
    <?php echo e(url("guardarDocente")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('nombreTipodeInformacion'); ?>
    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información Profesional')); ?></h6>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('informacionporTipo'); ?>
    <input type="hidden" id="tipo" name="tipo" value="docente">
    <div class="form-row">
        <div class="form-group col-md">
            <label class="form-control-label" for="input-estudios"><?php echo e(__('Grado de Estudios')); ?></label>
            <input type="text" class="form-control" id="input-estudios" name="estudios" value="<?php echo e(old('estudios')); ?>">
            
        </div>
        <div class="form-group col-md">
            <label class="form-control-label" for="input-estatus"><?php echo e(__('Estatus')); ?></label>
            <select id="input-estatus" class="form-control" name="estatus">
                <option selected></option>
                <option value="Activo"><?php echo e(__('Activo')); ?></option>
                <option value="Inactivo"><?php echo e(__('Inactivo')); ?></option>
            </select>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label class="form-control-label" for="input-rfc"><?php echo e(__('RFC')); ?></label>
            <div class="form-group">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="input-rfc" aria-describedby="input-rfc" name="rfc" value="<?php echo e(old('rfc')); ?>">
                    <label class="custom-file-label" for="input-rfc"></label>
                </div>
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label class="form-control-label" for="input-titulo"><?php echo e(__('Título')); ?></label>
            <div class="form-group">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="input-titulo" aria-describedby="input-titulo" name="titulo" value="<?php echo e(old('titulo')); ?>">
                    <label class="custom-file-label" for="input-titulo"></label>
                </div>
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label class="form-control-label" for="input-cedula"><?php echo e(__('Cédula Profesional')); ?></label>
            <div class="form-group">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="input-cedula" aria-describedby="input-cedula" name="cedula" value="">
                    <label class="custom-file-label" for="input-cedula"></label>
                </div>
                
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label class="form-control-label" for="input-certificaciones"><?php echo e(__('Certificaciones')); ?></label>
            <div class="form-group">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="input-certificaciones" aria-describedby="input-certificaciones" name="certificaciones[]" value="" multiple>
                    <label class="custom-file-label" for="input-certificaciones"></label>
                </div>
                
            </div>
        </div>
    </div> 
    
    <?php $__env->startSection('script'); ?>
        <script>
        $('.custom-file-input').on('change', function(event) {
            var inputFile = event.currentTarget;
            $(inputFile).parent()
                .find('.custom-file-label')
                .html(inputFile.files[0].name);
        });
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('viewsBase.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/docentes/createDocente.blade.php ENDPATH**/ ?>