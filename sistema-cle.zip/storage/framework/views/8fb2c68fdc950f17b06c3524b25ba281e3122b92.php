<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid m--t">
        <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center">
            <div class="col-lg col-md">
                <h4 class="text-dark">Evaluaci&oacute;n Docente</h4>
            </div>
        </div>
        <div class="card-body">
            <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    
        <div class="text-right">
            <a href="<?php echo e(route('inicio')); ?>" class="btn btn-outline-primary btn-sm mt-1">
                <span>
                    <i class="fas fa-reply"></i> &nbsp; Regresar
                </span>
            </a>
        </div>

        <div class="row mt-5">
            <div class="col-md-3"></div>
            <div class="col-md-2 text-center">
                <a href="<?php echo e(route('evaluacion')); ?>" >
                    <i class="fas fa-tasks fa-5x text-dark"></i>
                    <h5 class="text-dark">Ver Evaluacion Docente</h5>
                </a>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-2 text-center">
                <a href="<?php echo e(route('periodoResultados')); ?>">
                    <i class="fas fa-user-check fa-5x text-dark"></i>
                    <h5 class="text-dark">Ver Resultados</h5>
                </a>
            </div>
        </div>
        <br><br><br><br><br>
        <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/evaluacionDocente/inicioEvaluacion.blade.php ENDPATH**/ ?>