<?php $__env->startSection('content'); ?>
<div class="header bg-gradient-lighter pb-8 pt-0 pt-md-0"><br><br>
    <div class="container-fluid m--t">
            
                    <div class="text-right">
                        <a href="<?php echo e(route('inicio')); ?>" class="btn btn-outline-primary btn-sm mt-4">
                            <span>
                                <i class="fas fa-reply"></i> &nbsp; Regresar
                            </span>
                        </a>
                    </div>
        <div class="header-body">
            <!-- Card stats -->
            <div class="row mt-4">
                <div class="col-xl col-lg">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <a href="<?php echo e(route('verNiveles')); ?>"><div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <span class="font-weight-bold mb-0"><?php echo e(__('Niveles')); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                        <i class="fas fa-cubes"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                </div>
                <div class="col-xl col-lg">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <a href="<?php echo e(route('verAulas')); ?>">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class=" font-weight-bold mb-0"><?php echo e(__('Aulas')); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-orange text-white rounded-circle shadow">
                                            <i class="fas fa-chalkboard"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-xl col-lg">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <a href="<?php echo e(route('periodos')); ?>">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class=" font-weight-bold mb-0"><?php echo e(__('Periodos')); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-yellow text-white rounded-circle shadow">
                                            <i class="fas fa-user-clock"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-xl col-lg">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <a href="<?php echo e(route('clasificacion')); ?>">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class=" font-weight-bold mb-0"><?php echo e(__('Clasificación Preguntas')); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-green text-white rounded-circle shadow">
                                            <i class="far fa-check-square"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                
            </div>
            <div class="row mt-4">
                <div class="col-xl col-lg">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <a href="<?php echo e(route('plantillaDocentes')); ?>">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class=" font-weight-bold mb-0"><?php echo e(__('Plantilla de Docentes')); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-purple text-white rounded-circle shadow">
                                            <i class="fas fa-clipboard-list"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-xl col-lg">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <a href="<?php echo e(route('recuperarEstudiantes')); ?>">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class=" font-weight-bold mb-0"><?php echo e(__('Recuperar Datos de Estudiantes')); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                                            <i class="fas fa-users"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-xl col-lg">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <a href="<?php echo e(route('respaldo')); ?>">
                             <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class=" font-weight-bold mb-0"><?php echo e(__('Respaldar Datos')); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gray text-white rounded-circle shadow">
                                            <i class="far fa-save"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div> 
            </div>
            
        </div>
    </div>
</div>
<br><br>
<?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/catalogos/cardscatalogos.blade.php ENDPATH**/ ?>