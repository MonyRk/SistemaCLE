<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center" >
    <div class="col-lg col-md">
        <h4 class="text-dark">Grupo <?php echo e($grupo[0]->grupo); ?> <?php echo e($grupo[0]->nivel); ?><?php echo e($grupo[0]->modulo); ?></h4>
        <h6 class="text-dark"><?php echo e($grupo[0]->edificio); ?><?php echo e($grupo[0]->aula); ?> <?php echo e($grupo[0]->hora); ?></h6>
        <h6 class="text-dark"><?php echo e($periodo_actual[0]->descripcion); ?> <?php echo e($periodo_actual[0]->anio); ?></h6>   
    </div>
</div>
    <div class="container-fluid m--t"> 
        <div class="text-right">
            <a href="<?php echo e(back()); ?>" class="btn btn-outline-primary btn-sm mt-4">
                <span>
                    <i class="fas fa-reply"></i> &nbsp; Regresar
                    <input type="hidden" name="periodo" value="<?php echo e($grupo[0]->periodo); ?>">
                </span>
            </a>
        </div>
        <div class="row">
           
            <div class="col-md">
                    
            </div>
            
        </div>
        <div class="card-body">
            <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="pl-lg-4"> <?php $nivel =  $grupo[0]->nivel.$grupo[0]->modulo ?>
            <form method="post" action="<?php echo e(route('modificarLista')); ?>" autocomplete="off">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <input type="hidden" name="grupo" value="<?php echo e($grupo[0]->id_grupo); ?>">
                <input type="hidden" name="periodo" value="<?php echo e($grupo[0]->periodo); ?>">
                <input type="hidden" name="cupo" value="<?php echo e($grupo[0]->cupo); ?>">
                <div class="row">
<div class="col-xl">
        <div class="card shadow" >
            <div class="card-header border-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="heading-small text-muted mb-4"><?php echo e(__('Estudiantes Inscritos')); ?></h6>
                    </div>
                    
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-items-center table-flush th" id="datatable2">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">Núm.</th>
                            <th scope="col">Número <br> de Control</th>
                            <th scope="col">Nombre</th>
                            
                            <th scope="col">Quitar de <br> la lista</th>
                        </tr>
                    </thead>
                    <tbody><?php ($i=1); ?>
                        <?php $__currentLoopData = $alumnos_en_el_grupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row">
                           <?php echo e($i); ?>

                        </th>
                        <th scope="row">
                            <?php echo e($ag->num_control); ?>

                        </th>
                        <th scope="row">
                            <?php echo e($ag->nombres); ?> <?php echo e($ag->ap_paterno); ?> <?php echo e($ag->ap_materno); ?>

                        </th>
                        <td scope="row">
                                <div class="custom-control custom-control-alternative custom-checkbox">
                                        <input class="custom-control-input" id="<?php echo e($ag->num_control); ?>" name="quitar[]" type="checkbox" value="<?php echo e($ag->num_control); ?>">
                                        <label class="custom-control-label" for="<?php echo e($ag->num_control); ?>">o</label>
                                    </div>
                            <span>
                                
                            </span>
                        </td>
                        
                        </tr><?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="text-center">
                <button type="submit" class="btn btn-primary mt-4" id="guardar"><?php echo e(__('Modificar Lista')); ?></button>
            </div>
    </div>
    
</form>

    </div>
    </div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/inscripciones/listaQuitar.blade.php ENDPATH**/ ?>