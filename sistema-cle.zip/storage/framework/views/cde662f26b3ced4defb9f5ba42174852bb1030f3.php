<!DOCTYPE html>
<html>

<head>
    <style>
        table,
        th,
        td {
            table-layout: fixed;
            border: 1px solid black;
            border-collapse: collapse;
            word-wrap: break-word;
        }

        .alto-30 {
            height: 30px;
        }

        .alto-50 {
            height: 50px;
        }
        .ancho-30{
            width: 30px;
        }
        .ancho-40{
            width: 40px;
        }
        .ancho-50{
            width: 50px;
        }
        #caja {
            width: 100%;
            height: 50px;
        }

        #texto-uno {
            float: left;
            padding-left: 8%;  
            line-height: 10%;
            text-transform: uppercase
        }

        #texto-dos {
            float: right;
            padding-right: 5%;
            line-height: 20%;
            text-transform: uppercase
        }
    </style>

</head>

<body>

    
    
    <br><br>
<?php
    $i=1;
?>
    <table style="width:100%">
       
            <thead>
                <tr>
                    <th scope="col" class="ancho-30">No.</th>
                    <th scope="col"> Nombre</th>
                    <th scope="col" class="ancho-40">Sexo</th>
                    <th scope="col" class="ancho-40">Edad</th>
                    <th scope="col" class="alto-50" align="center">&Uacute;ltimo Grado de Estudios</th>
                    <th scope="col" class="alto-50" align="center">Certificaci&oacute;n del Dominio del Idioma</th>
                    <th scope="col" class="alto-50" align="center">Curso de Entrenamiento para Profesores (Teacher's Training Course)</th>
                    <th scope="col" class="alto-50" align="center">Certificaciones de Did&aacute;ctica</th>
                    <th scope="col" class="alto-50 ancho-50" align="center">Años de Experiencia Docente</th>
                    <th scope="col" class="alto-50" align="center">3 &Uacute;ltimas Actualizaciones Docentes</th>
                
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td scope="col" class="alto-50 ancho-30" align="center"><?php echo e($i++); ?></td>
                    <td scope="col" class="alto-50" align="center"><?php echo e($docente->nombres); ?> <?php echo e($docente->ap_paterno); ?> <?php echo e($docente->ap_materno); ?></td>
                    <td scope="col" class="alto-50 ancho-40" align="center"><?php echo e($docente->sexo); ?></td>
                    <td scope="col" class="alto-50 ancho-40" align="center"><?php echo e($docente->edad); ?></td>
               
                    <td scope="col" class="alto-50" align="center"><?php echo e($docente->grado_estudios); ?></td>
                    <td scope="col" class="alto-50" align="center"><?php echo e($docente->dominio_idioma); ?></td>
                    <td scope="col" class="alto-50" align="center"><?php echo e($docente->curso); ?></td>
                
                    <td scope="col" class="alto-50" align="center">
                        <?php $didacticas = ""; $didacticas = explode(';',$docente->didactica); ?>
                        <?php $__currentLoopData = $didacticas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre_didactica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($nombre_didactica); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td scope="col" class="alto-50 ancho-50" align="center"><?php echo e($docente->experiencia); ?></td>
                    <td scope="col" class="alto-50" align="center">
                        <?php $actualizaciones = ""; $actualizaciones = explode(';',$docente->actualizacion); ?>
                        <?php $__currentLoopData = $actualizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre_actualizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($nombre_actualizacion); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      
    </table>

</body>

</html><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/pdf/plantillapdf.blade.php ENDPATH**/ ?>