<?php $__env->startSection('sidebar'); ?>
<?php
$usuarioactual = \Auth::user();
?>
<?php if($usuarioactual->tipo == 'coordinador'): ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if($usuarioactual->tipo == 'alumno'): ?>
<?php echo $__env->make('layouts.navbars.sidebarEstudiantes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if($usuarioactual->tipo == 'docente'): ?>
<?php echo $__env->make('layouts.navbars.sidebarDocentes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if($usuarioactual->tipo == 'escolares'): ?>
<?php echo $__env->make('layouts.navbars.sidebarEscolares', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid m--t">
    <div class="header pb-1 pt-4 pt-lg-7 d-flex align-items-center text-center" >
        <div class="col-lg col-md">
            <h4 class="text-dark">Calificaciones</h4>
        </div>
    </div>
    <div class="card-body">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>  
            </div> 
        <?php endif; ?>
    </div>

    <div class="text-right">
        
        <a href="<?php echo e(route('boletas')); ?>" class="btn btn-outline-primary btn-sm mt-4">
            <span>
                <i class="fas fa-reply"></i> &nbsp; Regresar
            </span>
        </a>
    </div>

    <form action="<?php echo e(route('verBoleta','grupo')); ?>" method="GET">
        <div class="row">
            <div class="col-lg-4"></div>
            <div class="col-lg-4 text-center">
                <div class="row">
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-periodo"><?php echo e(__('Periodo')); ?></label>
                        <select  id="input-periodo" class="form-control" name="periodo">
                           <?php if($usuarioactual->tipo != 'alumno'): ?><option selected value="<?php echo e(old('periodo')); ?>"></option> <?php endif; ?>
                            <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($periodo->id_periodo); ?>" <?php if($usuarioactual->tipo == 'alumno' && $periodo->actual == true): ?> selected <?php endif; ?>><?php echo e($periodo->descripcion); ?> <?php echo e($periodo->anio); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row" <?php if($usuarioactual->tipo == 'alumno'): ?> style="display:none;" <?php else: ?> style="display:block;" <?php endif; ?>>
                    <div class="form-group col-md">
                        <label class="form-control-label" for="input-grupo"><?php echo e(__('Grupos')); ?></label>
                        <select  id="input-grupo" class="form-control" name="grupo">
                            
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-lg-4"></div>
        </div>
        
            
        <div class="text-center">
            <button type="submit" class="btn btn-primary btn-lg mt-4"><span><i class="fas fa-arrow-right"></i></span></button>
        </div>
    </form>
    <br><br>
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>



<?php $__env->startSection('script'); ?>
<?php if($usuarioactual->tipo == 'docente'): ?> 
    <?php echo e($query='boletaGrupos'); ?>




<?php else: ?>
   <?php echo e($query='boletaGrupo'); ?> 
<?php endif; ?>
<script>
    var $jq = jQuery.noConflict();
    $jq(document).ready(function(){
        $jq('#input-periodo').on('change',function(){
            var id_periodo_seleccionado = $jq(this).val();
            if ($jq.trim(id_periodo_seleccionado) != ''){
                $jq.get('<?php echo($query) ?>',{id_periodo: id_periodo_seleccionado},function(grupos){
                    $jq('#input-grupo').empty();
                    $jq('#input-grupo').append("<option value=''></option>");
                    $jq.each(grupos, function(index, value){ 
                                $jq('#input-grupo').append("<option value='"+ index +"'>"+ value +"</option>");
                    });
                });
            }
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/boletas/boletas.blade.php ENDPATH**/ ?>