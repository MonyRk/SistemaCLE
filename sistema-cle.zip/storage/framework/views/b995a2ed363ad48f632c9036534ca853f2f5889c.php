<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md pt-3">
            <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-block pt-2">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="text-right pb-4">
        <a href="<?php echo e(route('catalogos')); ?>" class="btn btn-outline-primary btn-sm mt-4">
            <span>
                <i class="fas fa-reply"></i> &nbsp; Regresar
            </span>
        </a>
    </div>

    
    <div class="row mt-3">
        <div class="col-xl">
            <div class="card shadow ">
                <div class="card-header border-3">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="mb-0"><?php echo e(__('Clasificación de Preguntas para la Evaluación Docente')); ?></h5>
                        </div>
                        <div class="col text-right">
                            <button type="button" class="btn btn-sm btn-white" data-toggle="modal" data-target="#modal-form2"><?php echo e(__('Agregar Clasificación ')); ?><i class="fas fa-plus-circle"></i></button>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <!-- Projects table -->
                    <table class="table align-items-center table-flush th">
                        <thead class="thead-light">
                            <tr>
                                <th></th>
                                <th scope="col">Clasificaci&oacute;n</th>
                                
                                <th scope="col">Editar</th>
                                

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th></th>
                                <th scope="row">
                                    <?php echo e($clasificacion->clasificacion); ?>

                                </th>
                                
                                <td>
                                    <a href="" class="text-primary" data-idclasificacion="<?php echo e($clasificacion->id_clasificacion); ?>" data-clasificacion="<?php echo e($clasificacion->clasificacion); ?>" data-toggle="modal" data-target="#modal-form3"><i class="fas fa-edit"></i></a>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
<br><br>
<?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<div class="col-md-4">

    <div class="modal fade" id="modal-form2" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="card bg-lighter shadow border-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <div class="text-center text-muted mb-4">
                                <strong><?php echo e(__('Nueva Clasificación')); ?></strong>
                            </div>

                            <form role="form" method="post" action="<?php echo e(route('agregarClasificacion')); ?>" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <input class="form-control" name="clasificacion" placeholder="Clasificación" type="text" value="<?php echo e(old('clasificacion')); ?>">
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Guardar')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-4">

    <div class="modal fade" id="modal-form3" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="card bg-lighter shadow border-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <div class="text-center text-muted mb-4">
                                <strong><?php echo e(__('Editar clasificacion')); ?></strong>
                            </div>

                            <form role="form" method="post" action="<?php echo e(route('guardarClasificacion','test')); ?>" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <input class="form-control" id="clasificacionn" name="clasificacion" placeholder="Clasificación" type="text" value="<?php echo e(old('clasificacion')); ?>">
                                        <input type="hidden" name="id_clasificacion" id="id_clasificacion" value="">
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Actualizar')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="col-md-4">
    <div class="modal fade" id="modal-notification" tabindex="-1" role="dialog" aria-labelledby="modal-notification" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-" role="document">
            <div class="modal-content bg-gradient-white">

                <div class="modal-header">
                    <h6 class="modal-title" id="modal-title-notification">¡Espera!</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                </div>
                <form action="<?php echo e(route('eliminarClasificacion','test')); ?>" method="POST" class="delete" id="deleteForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <div class="modal-body">

                        <div class="py-3 text-center">
                            <i class="fas fa-times fa-3x" style="color:#CD5C5C;"></i>
                            <h4 class="heading mt-4">¡Da tu confirmaci&oacute;n para Eliminar!</h4>
                            <p>¿Realmente deseas eliminar la respuesta?</p>
                            <input type="hidden" name="id_r_eliminar" id="id_r_eliminar" value="">
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-outline-danger">S&iacute;, Eliminar</button>
                        <button type="button" class="btn btn-link text-gray ml-auto" data-dismiss="modal">No, Cambi&eacute; de opinion</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




<div class="col-md-4">

    <div class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="card bg-lighter shadow border-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <div class="text-center text-muted mb-4">
                                <strong><?php echo e(__('Nuevo Grupo de Respuestas')); ?></strong>
                            </div>

                            <form role="form" method="post" action="<?php echo e(route('agregargrupoR')); ?>" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-pencil-alt"></i></span>
                                        </div>
                                        <input class="form-control" name="grupoR" placeholder="Grupo de Respuesta" type="text" value="<?php echo e(old('grupoR')); ?>">
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="sumbit" class="btn btn-primary my-4"><?php echo e(__('Guardar')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>





<?php $__env->startSection('script'); ?>
<script>
    // para eliminar
    $('#modal-notification').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget)
        var id_res = button.attr('data-respuid')
        var modal = $(this)
        modal.find('.modal-body #id_r_eliminar').val(id_res);
    })



    // para editar
    $('#modal-form3').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget)
        var id_clasificacion = button.attr('data-idclasificacion')
        var clasificacion = button.attr('data-clasificacion')
        var modal = $(this)
        modal.find('.modal-body #clasificacionn').val(clasificacion);
        modal.find('.modal-body #id_clasificacion').val(id_clasificacion);
    })
</script>
<?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\sistema-cle\resources\views/catalogos/clasificacion/clasificaciones.blade.php ENDPATH**/ ?>